package gui;

import client.ClientUI;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logic.SubscriberLoginRequest;   // <-- Make sure this exists

public class SubscriberLoginController {

    @FXML
    private TextField subscriberIdField;

    @FXML
    private TextField confirmationCodeField;

    @FXML
    private Label errorLabel;

    @FXML
    private void onLogin() {
        String id = subscriberIdField.getText();
        String code = confirmationCodeField.getText();

        // ===== Validation =====
        if (id == null || id.trim().isEmpty()) {
            errorLabel.setText("Subscriber ID is required");
            return;
        }

        if (code == null || code.trim().isEmpty()) {
            errorLabel.setText("Confirmation code is required");
            return;
        }

        // ===== Send to Server =====
        try {
            SubscriberLoginRequest req = new SubscriberLoginRequest(id, code);
            ClientUI.chat.sendToServer(req);
            errorLabel.setText(""); // clear error if previously shown
        } 
        catch (Exception e) {
            errorLabel.setText("Failed to connect to server");
        }
    }

    @FXML
    private void onBack() {
        Stage stage = (Stage) subscriberIdField.getScene().getWindow();
        stage.close();
    }

    // ===== Helper to show server response errors from ClientController =====
    public static void showServerError(String msg) {
        Platform.runLater(() -> {
            // You may change this later to a popup instead
            System.out.println("Server Error: " + msg);
        });
    }
}
