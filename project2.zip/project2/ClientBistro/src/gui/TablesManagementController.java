package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class TablesManagementController {

    @FXML
    private TableView<?> tablesTable;

    @FXML
    private TextField capacityField;

    @FXML
    private Label statusLabel;

    @FXML
    private void addTable() {
        statusLabel.setText("Add Table clicked (UI only)");
    }

    @FXML
    private void updateTable() {
        statusLabel.setText("Update Table clicked (UI only)");
    }

    @FXML
    private void deleteTable() {
        statusLabel.setText("Delete Table clicked (UI only)");
    }
}
