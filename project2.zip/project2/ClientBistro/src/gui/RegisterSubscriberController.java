package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class RegisterSubscriberController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField emailField;

    @FXML
    private Label resultLabel;

    @FXML
    private void createSubscriber() {
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();

        if (name == null || name.isEmpty() ||
            phone == null || phone.isEmpty() ||
            email == null || email.isEmpty()) {

            resultLabel.setText("Please fill all fields");
            return;
        }

        int code = 100000 + (int)(Math.random() * 900000);

        resultLabel.setText("Subscriber created!\nSubscriber Code: " + code);
    }
}
