package Server;

import java.sql.*;
import java.sql.Date;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.concurrent.*;

import logic.*;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class EchoServer extends AbstractServer {
	String emailForCode=null;
    private final Map<ConnectionToClient, String> clientIPs = new ConcurrentHashMap<>();

    public EchoServer(int port) {
        super(port);
    }

    // =====================================================
    //               MESSAGE HANDLER
    // =====================================================
    @Override
    public void handleMessageFromClient(Object msg, ConnectionToClient client) {

        System.out.println("[Client] Message from IP: " +
                clientIPs.getOrDefault(client, "UNKNOWN"));

        MySQLConnectionPool pool = null;
        Connection conn = null;

        try {
            pool = MySQLConnectionPool.getInstance();
            conn = pool.getConnection();

            if (msg instanceof SubscriberLoginRequest loginReq) {
                handleSubscriberLogin(conn, loginReq, client);
                return;
            }

            if (msg instanceof Request req) {
                switch (req.getStatus()) {

                    // ----- RESERVATION FLOW -----
                    case "CHECK_AVAILABILITY" -> handleCheckAvailability(conn, req, client);
                    case "CREATE_RESERVATION" -> handleCreateReservation(conn, req, client);

                    // ----- TERMINAL FLOW -----
                    case "TERMINAL_CHECKIN" -> handleTerminalCheckIn(conn, req, client);

                    // ----- CANCEL / PAY -----
                    case "CANCEL_ORDER" -> handleCancelOrder(conn, req, client);
                    case "PAY_BILL" -> handlePayment(conn, req, client);

                    // ----- HISTORY -----
                    case "GET_ACCOUNT_HISTORY" -> sendAccountHistory(conn, (int) req.getData(), client);
                    case "FREE_TABLES" -> handleFreeTables(conn, req, client);
                    case "INSERT_NEW_CUSTOMER" -> handleInsertCustomer(conn, req, client);
                    case "INSERT_NEW_ORDER" -> handleInsertOrder(conn, req, client);
                    case "CONFIRMATION_CODE" -> handleConfirmationCode(conn, req, client);
                    case "SEND_CODE" -> handleSendCode(conn,req,client);

                    default -> System.out.println("[Server] Unknown request: " + req.getStatus());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            try { client.sendToClient("SERVER_ERROR"); } catch (Exception ignored) {}
        } finally {
            if (pool != null && conn != null) {
                pool.releaseConnection(conn);
            }
        }
    }

    // =====================================================
    // Helpers
    // =====================================================

    // guests -> table category: 2/4/6/10
    private int requiredPlacesForGuests(int guests) {
        if (guests <= 2) return 2;
        if (guests <= 4) return 4;
        if (guests <= 6) return 6;
        return 10;
    }

    // Accepts "17:30" OR "17:30:00"
    private LocalTime parseTimeFlexible(String s) {
        if (s == null) throw new IllegalArgumentException("time is null");
        try {
            return LocalTime.parse(s); // works for HH:mm:ss
        } catch (DateTimeParseException ex) {
            // try HH:mm
            return LocalTime.parse(s, DateTimeFormatter.ofPattern("H:mm"));
        }
    }

    // =====================================================
    // 1) RESERVATION: CHECK AVAILABILITY (NO TABLE ASSIGNMENT)
    // =====================================================
    private void handleCheckAvailability(Connection conn, Request req, ConnectionToClient client) throws Exception {
        Order o = (Order) req.getData();

        LocalDate date = LocalDate.parse(o.getOrder_date());
        LocalTime time = parseTimeFlexible(o.getOrder_time());
        int guests = o.getNumber_of_guests();

        int requiredPlaces = requiredPlacesForGuests(guests);

        // IMPORTANT: exact match ONLY (because you said we cannot give bigger table)
        int totalFitTables = countExactFitTables(conn, requiredPlaces);
        int overlapping = countOverlappingReservationsByCategory(conn, date, time, requiredPlaces);

        if (overlapping < totalFitTables) {
            client.sendToClient(new Response("AVAILABLE", null));
        } else {
            List<String> suggestions = suggestTimes(conn, date, time, requiredPlaces);
            client.sendToClient(new Response("NOT_AVAILABLE", suggestions));
        }
    }

    // EXACT FIT: places = requiredPlaces (NOT >=)
    private int countExactFitTables(Connection conn, int requiredPlaces) throws SQLException {
        String sql = "SELECT COUNT(*) FROM tables WHERE places = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, requiredPlaces);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    // Count overlapping orders that consume the same category (2/4/6/10)
    private int countOverlappingReservationsByCategory(Connection conn, LocalDate date, LocalTime time, int requiredPlaces) throws SQLException {
        String sql =
                "SELECT COUNT(*) " +
                "FROM `order` o " +
                "WHERE o.order_date = ? " +
                "AND o.order_status IN ('BOOKED','SEATED','PAYED') " +
                "AND (CASE " +
                "       WHEN o.number_of_guests <= 2 THEN 2 " +
                "       WHEN o.number_of_guests <= 4 THEN 4 " +
                "       WHEN o.number_of_guests <= 6 THEN 6 " +
                "       ELSE 10 " +
                "     END) = ? " +
                "AND (TIME(?) < ADDTIME(o.order_time, '02:00:00') " +
                "     AND o.order_time < ADDTIME(TIME(?), '02:00:00'))";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setInt(2, requiredPlaces);
            ps.setTime(3, Time.valueOf(time));
            ps.setTime(4, Time.valueOf(time));
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    private List<String> suggestTimes(Connection conn, LocalDate date, LocalTime requested, int requiredPlaces) throws SQLException {
        LocalTime open = LocalTime.parse("17:00");
        LocalTime close = LocalTime.parse("21:30");

        List<LocalTime> candidates = List.of(
                requested.minusMinutes(60),
                requested.minusMinutes(30),
                requested.plusMinutes(30),
                requested.plusMinutes(60),
                requested.plusMinutes(90),
                requested.plusMinutes(120)
        );

        List<String> suggestions = new ArrayList<>();

        for (LocalTime c : candidates) {
            if (c.isBefore(open) || c.isAfter(close)) continue;

            int total = countExactFitTables(conn, requiredPlaces);
            int overlap = countOverlappingReservationsByCategory(conn, date, c, requiredPlaces);

            if (overlap < total) {
                suggestions.add(c.toString());
                if (suggestions.size() == 3) break;
            }
        }
        return suggestions;
    }

    // =====================================================
    // 2) RESERVATION: CREATE RESERVATION (GENERATE CODE, NO TABLE)
    // =====================================================
    private void handleCreateReservation(Connection conn, Request req, ConnectionToClient client) throws Exception {
        Order o = (Order) req.getData();

        LocalDate date = LocalDate.parse(o.getOrder_date());
        LocalTime time = parseTimeFlexible(o.getOrder_time());
        int guests = o.getNumber_of_guests();

        int requiredPlaces = requiredPlacesForGuests(guests);

        // ---------- TRANSACTION + LOCK (prevents race / double insert) ----------
        conn.setAutoCommit(false);
        try {
            // lock matching rows so two clients cannot pass the check at same moment
            int totalFitTables = countExactFitTables(conn, requiredPlaces);
            int overlapping = countOverlappingReservationsByCategoryForUpdate(conn, date, time, requiredPlaces);

            if (overlapping >= totalFitTables) {
                List<String> suggestions = suggestTimes(conn, date, time, requiredPlaces);
                conn.rollback();
                client.sendToClient(new Response("NOT_AVAILABLE", suggestions));
                return;
            }

            int confirmationCode = generateUniqueConfirmationCode(conn);

            String insertSql =
                    "INSERT INTO `order` " +
                    "(order_date, order_time, number_of_guests, confirmation_code, subscriber_id, " +
                    "customer_phone, customer_email, date_of_placing_order, table_num, order_status, status_datetime) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 'BOOKED', NOW())";

            try (PreparedStatement ps = conn.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setDate(1, Date.valueOf(date));
                ps.setTime(2, Time.valueOf(time));
                ps.setInt(3, guests);
                ps.setInt(4, confirmationCode);
                ps.setInt(5, o.getSubscriber_id());
                ps.setString(6, o.getCustomer_phone());
                ps.setString(7, o.getCustomer_email());
                ps.setDate(8, Date.valueOf(LocalDate.parse(o.getDate_of_placing_order())));

                ps.executeUpdate();

                int orderNumber = -1;
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) orderNumber = keys.getInt(1);
                }

                conn.commit();

                Map<String, Object> payload = new HashMap<>();
                payload.put("orderNumber", orderNumber);
                payload.put("confirmationCode", confirmationCode);

                client.sendToClient(new Response("RESERVATION_CREATED", payload));
            }

        } catch (Exception ex) {
            conn.rollback();
            throw ex;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    // same as countOverlappingReservationsByCategory but locks rows (race-safe)
    private int countOverlappingReservationsByCategoryForUpdate(Connection conn, LocalDate date, LocalTime time, int requiredPlaces) throws SQLException {
        String sql =
                "SELECT COUNT(*) " +
                "FROM `order` o " +
                "WHERE o.order_date = ? " +
                "AND o.order_status IN ('BOOKED','SEATED','PAYED') " +
                "AND (CASE " +
                "       WHEN o.number_of_guests <= 2 THEN 2 " +
                "       WHEN o.number_of_guests <= 4 THEN 4 " +
                "       WHEN o.number_of_guests <= 6 THEN 6 " +
                "       ELSE 10 " +
                "     END) = ? " +
                "AND (TIME(?) < ADDTIME(o.order_time, '02:00:00') " +
                "     AND o.order_time < ADDTIME(TIME(?), '02:00:00')) " +
                "FOR UPDATE";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setInt(2, requiredPlaces);
            ps.setTime(3, Time.valueOf(time));
            ps.setTime(4, Time.valueOf(time));
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    private int generateUniqueConfirmationCode(Connection conn) throws SQLException {
        Random rnd = new Random();
        while (true) {
            int code = 100000 + rnd.nextInt(900000); // 6 digits

            String checkSql = "SELECT 1 FROM `order` WHERE confirmation_code=? LIMIT 1";
            try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
                ps.setInt(1, code);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) return code; // unique
                }
            }
        }
    }

    // =====================================================
    // 3) TERMINAL: CHECKIN BY CONFIRMATION CODE + BEST-FIT TABLE
    // =====================================================
    private void handleTerminalCheckIn(Connection conn, Request req, ConnectionToClient client) throws Exception {
        int code = (int) req.getData();

        String findSql = "SELECT * FROM `order` WHERE confirmation_code=?";
        Order o;

        try (PreparedStatement ps = conn.prepareStatement(findSql)) {
            ps.setInt(1, code);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    client.sendToClient(new Response("CODE_NOT_FOUND", null));
                    return;
                }

                o = new Order(
                        rs.getInt("order_number"),
                        rs.getString("order_date"),
                        rs.getString("order_time"),
                        rs.getInt("number_of_guests"),
                        rs.getInt("confirmation_code"),
                        rs.getInt("subscriber_id"),
                        rs.getString("customer_phone"),
                        rs.getString("customer_email"),
                        rs.getString("date_of_placing_order"),
                        rs.getInt("table_num"),
                        rs.getString("order_status"),
                        rs.getString("status_datetime")
                );
            }
        }

        if (!"BOOKED".equalsIgnoreCase(o.getOrder_status())) {
            client.sendToClient(new Response("CHECKIN_NOT_ALLOWED", o.getOrder_status()));
            return;
        }

        int guests = o.getNumber_of_guests();

        Integer tableNum = findBestFitFreeTable(conn, guests);
        if (tableNum == null) {
            client.sendToClient(new Response("NO_TABLE_AVAILABLE", null));
            return;
        }

        String updateSql =
                "UPDATE `order` SET table_num=?, order_status='SEATED', status_datetime=NOW() " +
                "WHERE confirmation_code=?";

        try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
            ps.setInt(1, tableNum);
            ps.setInt(2, code);
            ps.executeUpdate();
        }

        Map<String, Object> payload = new HashMap<>();
        payload.put("table_num", tableNum);
        payload.put("confirmation_code", code);

        client.sendToClient(new Response("CHECKIN_SUCCESS", payload));
    }

    private Integer findBestFitFreeTable(Connection conn, int guests) throws SQLException {
        String sql =
                "SELECT t.table_num " +
                "FROM tables t " +
                "WHERE t.places >= ? " +
                "AND t.table_num NOT IN (" +
                "   SELECT o.table_num FROM `order` o " +
                "   WHERE o.order_status='SEATED' AND o.table_num IS NOT NULL" +
                ") " +
                "ORDER BY t.places ASC, t.table_num ASC " +
                "LIMIT 1";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, guests);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
                return null;
            }
        }
    }

    // =====================================================
    // CANCEL / PAYMENT
    // =====================================================
    private void handleCancelOrder(Connection conn, Request req, ConnectionToClient client) throws Exception {
        int code = (int) req.getData();

        String sql =
                "UPDATE `order` SET order_status='CANCELLED_BY_USER', status_datetime=NOW() " +
                "WHERE confirmation_code=? AND order_status='BOOKED'";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, code);
            int updated = ps.executeUpdate();
            client.sendToClient(new Response(updated > 0 ? "CANCEL_SUCCESS" : "CANCEL_FAILED", null));
        }
    }

    private void handlePayment(Connection conn, Request req, ConnectionToClient client) throws Exception {
        int code = (int) req.getData();

        String sql =
                "UPDATE `order` SET order_status='PAYED', status_datetime=NOW() " +
                "WHERE confirmation_code=? AND order_status='SEATED'";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, code);
            int updated = ps.executeUpdate();
            client.sendToClient(new Response(updated > 0 ? "PAYMENT_SUCCESS" : "PAYMENT_FAILED", null));
        }
    }

    // =====================================================
    // SUBSCRIBER LOGIN
    // =====================================================
    private void handleSubscriberLogin(Connection conn, SubscriberLoginRequest req,
                                       ConnectionToClient client) throws Exception {

        String sql =
                "SELECT * FROM subscriber WHERE subscriber_id=? AND BINARY subscriber_name=?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(req.getSubscriberId()));
            ps.setString(2, req.getSubscriberName());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    client.sendToClient(new Subscriber(
                            rs.getInt("subscriber_id"),
                            rs.getString("subscriber_name"),
                            rs.getString("subscriber_email"),
                            rs.getString("subscriber_phone")
                    ));
                } else {
                    client.sendToClient("LOGIN_FAIL");
                }
            }
        }
    }

    // =====================================================
    // ACCOUNT HISTORY
    // =====================================================
    private void sendAccountHistory(Connection conn, int subscriberId, ConnectionToClient client) throws Exception {

        List<Order> orders = new ArrayList<>();

        String sql =
                "SELECT * FROM `order` " +
                "WHERE subscriber_id=? " +
                "ORDER BY order_date DESC, order_time DESC";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, subscriberId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    orders.add(new Order(
                            rs.getInt("order_number"),
                            rs.getString("order_date"),
                            rs.getString("order_time"),
                            rs.getInt("number_of_guests"),
                            rs.getInt("confirmation_code"),
                            rs.getInt("subscriber_id"),
                            rs.getString("customer_phone"),
                            rs.getString("customer_email"),
                            rs.getString("date_of_placing_order"),
                            rs.getInt("table_num"),
                            rs.getString("order_status"),
                            rs.getString("status_datetime")
                    ));
                }
            }
        }

        client.sendToClient(new Response("ACCOUNT_HISTORY", orders));
    }
    
    private void handleFreeTables(Connection conn, Request req, ConnectionToClient client) throws Exception {
	    Order o = (Order) req.getData();

	    int guests = o.getNumber_of_guests();
	    String date = o.getOrder_date();
	    String time = o.getOrder_time();

	    List<Tables> freeTables = new ArrayList<>();
	    
	    int tablePlace = 0;
        if (guests==2) tablePlace = 2;
        else if (guests>=3 && guests<=4) tablePlace = 4;
        else if (guests>=5 && guests<=6) tablePlace = 6;
        else tablePlace = 10;

        String sql = "SELECT * FROM tables t WHERE t.places = ? AND t.table_num NOT IN ( SELECT o.table_num FROM `order` o WHERE o.order_date = ? AND o.order_status IN ('BOOKED', 'SEATED') AND (TIME(?) < ADDTIME(o.order_time, '02:00:00') AND o.order_time < ADDTIME(TIME(?), '02:00:00')))";

	    try (PreparedStatement ps = conn.prepareStatement(sql)) {
	        ps.setInt(1, tablePlace);
	        ps.setString(2, date);
	        ps.setString(3, time);
	        ps.setString(4, time);

	        try (ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                freeTables.add(new Tables(
	                    rs.getInt("table_num"),
	                    rs.getInt("places")
	                ));
	            }
	        }
	        if (!freeTables.isEmpty()) {
	            client.sendToClient(new Response("FREE_TABLES_FOUND", freeTables));
	            System.out.println("[FREE TABLES FOUND] " + freeTables.toString());
	        } else {
	        	LocalTime toTime= LocalTime.parse(time);
	        	LocalTime requested = LocalTime.of(toTime.getHour(),toTime.getMinute());
	        	
	        	List<LocalTime> candidates = List.of(
	        			requested.minusMinutes(30),
	        			requested.minusMinutes(60),
	        			requested.plusMinutes(30),
	        			requested.plusMinutes(60),
	        			requested.plusMinutes(90),
	        			requested.plusMinutes(120)
	        	);
	        	
	        	
	        	List<LocalTime> suggestions = new ArrayList<>();

	        	for (LocalTime candidate : candidates) {
	        		String open = "17:00",close = "21:30";
	        		LocalTime openTime = LocalTime.parse(open);
	        		LocalTime closeTime = LocalTime.parse(close);
	        		
	        		if (candidate.isBefore(openTime) || candidate.isAfter(closeTime)) {
	        	        continue;
	        	    }
	        	    try (PreparedStatement ps2 = conn.prepareStatement(sql)) {
	        	        ps2.setInt(1, tablePlace);
	        	        ps2.setDate(2, Date.valueOf(date));
	        	        ps2.setTime(3, Time.valueOf(candidate));
	        	        ps2.setTime(4, Time.valueOf(candidate));

	        	        ResultSet rs = ps2.executeQuery();
	        	        if (rs.next()) {
	        	            suggestions.add(candidate);
	        	        }
	        	    }
	        	    if (suggestions.size()==3) break; 
	        	}
	            client.sendToClient(new Response("FREE_TABLES_NOT_FOUND", suggestions));
	            if (!suggestions.isEmpty()) System.out.println("[NO FREE TABLES] Sending Suggestions "+suggestions);
	            else System.out.println("[NO FREE TABLES]");
	            
	        }
	    }
	}
    
    private void handleInsertCustomer(Connection conn, Request req, ConnectionToClient client) throws Exception {
 		Customer c = (Customer)req.getData();
 		String sql ="INSERT INTO customer (customer_name,customer_email,customer_phone) VALUES (?, ?, ?)";

         try (PreparedStatement ps = conn.prepareStatement(sql)) {
         	ps.setString(1, c.getCustomer_name());
             ps.setString(2, c.getCustomer_email());
             ps.setString(3, c.getCustomer_phone());
             int updated = ps.executeUpdate();
             
             emailForCode = c.getCustomer_email();

             if (updated > 0) {
                 sendToAllClients("Customer inserted successfully!");
                 System.out.println("[DB] Customer inserted: " + c);
             } else {
                 sendToAllClients("Customer not inserted!");
                 System.out.println("[DB] Customer not inserted: " + c.getCustomer_name());
             }
         }

}
    
    private void handleInsertOrder(Connection conn, Request req, ConnectionToClient client) throws Exception {
    	Order o = (Order)req.getData();
		String sql ="INSERT INTO `order` (order_number,order_date,order_time,number_of_guests,confirmation_code,subscriber_id,customer_phone,customer_email,date_of_placing_order,table_num,order_status,status_datetime) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
        	ps.setInt(1, o.getOrder_number());
            ps.setString(2, o.getOrder_date());
            ps.setString(3, o.getOrder_time());
            ps.setInt(4, o.getNumber_of_guests());
            ps.setInt(5, o.getConfirmation_code());
            ps.setInt(6, o.getSubscriber_id());
            ps.setString(7, o.getCustomer_phone());
            ps.setString(8, o.getCustomer_email());
            ps.setString(9, o.getDate_of_placing_order());
            ps.setInt(10,o.getTable_num());
            ps.setString(11, o.getOrder_status());
            ps.setString(12, o.getStatus_datetime());

            int updated = ps.executeUpdate();

            if (updated > 0) {
            	 //EmailService.sendConfirmationEmail(o.getCustomer_email, o.getConfirmation_code());
            	client.sendToClient("Order inserted successfully!");
            	System.out.println("[DB] Order inserted: " + o);
            } else {
            	client.sendToClient("Order not inserted!");
                System.out.println("[DB] Order not inserted: " + o.getOrder_number());
            }
        }

    }
    
    private void handleConfirmationCode(Connection conn, Request req, ConnectionToClient client) throws Exception {

   	 int code = (int) req.getData();

   	String orderSql = "SELECT * FROM `order` WHERE confirmation_code = ? AND order_status IN ('BOOKED', 'SEATED')";

	    try (PreparedStatement ops = conn.prepareStatement(orderSql)) {

	        ops.setInt(1, code);

	        try (ResultSet ors = ops.executeQuery()) {

	            if (!ors.next()) {
	                client.sendToClient(new Response("CODE_NOT_FOUND", null));
	                System.out.println("[Confirmation Code] NOT FOUND");
	                return;
	            }

	            Order o = new Order(
	                    ors.getInt("order_number"),
	                    ors.getString("order_date"),
	                    ors.getString("order_time"),
	                    ors.getInt("number_of_guests"),
	                    ors.getInt("confirmation_code"),
	                    ors.getInt("subscriber_id"),
	                    ors.getString("customer_phone"),
	                    ors.getString("customer_email"),
	                    ors.getString("date_of_placing_order"),
	                    ors.getInt("table_num"),
	                    ors.getString("order_status"),
	                    ors.getString("status_datetime")
	            );
	            
	            String custSql = "SELECT * FROM customer WHERE customer_email = ?";
	            try (PreparedStatement cps = conn.prepareStatement(custSql)) {
	                cps.setString(1, ors.getString("customer_email"));
	                try (ResultSet crs = cps.executeQuery()) {
	                    Customer c = null;
	                    if (crs.next()) {
	                        c = new Customer(
	                                crs.getString("customer_name"),
	                                crs.getString("customer_email"),
	                                crs.getString("customer_phone")
	                        );
	                    }
	                    OrderCustomer oc = new OrderCustomer(o,c);
	                    Response response = new Response("CODE_FOUND",oc);
	                    client.sendToClient(response);
	                    System.out.println("[Confirmation Code] FOUND");
	                }
	}

   }
	    }
   }

    
    private void handleSendCode(Connection conn, Request req, ConnectionToClient client) throws SQLException {
        String email = (String) req.getData();

        String sql = """
            SELECT order_date, order_time, confirmation_code
            FROM `order`
            WHERE customer_email = ?
              AND order_status = 'BOOKED'
            ORDER BY order_date, order_time
            """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            List<String> codes = new ArrayList<>();
            while (rs.next()) {
                String date = rs.getString("order_date");
                String time = rs.getString("order_time");
                String code = rs.getString("confirmation_code");

                codes.add("• " + date + " at " + time + " — Code: " + code);
            }

            if (codes.isEmpty()) {
                System.out.println("[LOST CODE] No BOOKED orders found for email: " + email);
                return;
            }

            // EmailService.lostCodeEmail(email, codes);
        }
    }







    // =====================================================
    // SERVER EVENTS + TRIGGERS
    // =====================================================
    @Override
    protected void serverStarted() {
        System.out.println("[Server] Listening on port " + getPort());

        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(() -> {
            try { runTriggers(); }
            catch (Exception e) { e.printStackTrace(); }
        }, 0, 2, TimeUnit.MINUTES);
    }

    private void runTriggers() throws SQLException {
        try (Connection conn = MySQLConnectionPool.getInstance().getConnection()) {

            conn.prepareStatement(
                    "UPDATE `order` " +
                    "SET order_status='CANCELLED_NO_SHOW', status_datetime=NOW() " +
                    "WHERE order_status='BOOKED' " +
                    "AND TIMESTAMP(order_date, order_time) <= NOW() - INTERVAL 15 MINUTE"
            ).executeUpdate();

            conn.prepareStatement(
                    "UPDATE `order` " +
                    "SET order_status='COMPLETED' " +
                    "WHERE order_status='PAYED' " +
                    "AND status_datetime <= NOW() - INTERVAL 2 HOUR"
            ).executeUpdate();
        }
    }

    @Override
    protected void clientConnected(ConnectionToClient client) {
        clientIPs.put(client, client.getInetAddress().getHostAddress());
        System.out.println("[Client] Connected");
    }

    @Override
    protected void clientDisconnected(ConnectionToClient client) {
        clientIPs.remove(client);
    }
}
