package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class OpeningHoursController {

    @FXML
    private ComboBox<String> dayBox;

    @FXML
    private TextField openField;

    @FXML
    private TextField closeField;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        dayBox.getItems().addAll(
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Holiday / Special Day"
        );
    }

    @FXML
    private void saveHours() {
        String day = dayBox.getValue();
        String open = openField.getText();
        String close = closeField.getText();

        if (day == null || open.isEmpty() || close.isEmpty()) {
            statusLabel.setText("Please fill all fields");
            return;
        }

        statusLabel.setText("Opening hours updated (UI only)");
    }
    @FXML
    private void onLogout(javafx.event.ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/RoleSelection.fxml"));
            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) ((javafx.scene.Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
