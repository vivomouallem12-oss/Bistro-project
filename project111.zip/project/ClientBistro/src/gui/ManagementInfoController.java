package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ManagementInfoController {

    @FXML private Label todayReservationsLabel;
    @FXML private Label monthlyReservationsLabel;
    @FXML private Label canceledReservationsLabel;
    @FXML private Label subscribersLabel;
    @FXML private Label currentCustomersLabel;

    @FXML
    public void initialize() {
        todayReservationsLabel.setText("14");
        monthlyReservationsLabel.setText("238");
        canceledReservationsLabel.setText("21");
        subscribersLabel.setText("102");
        currentCustomersLabel.setText("29");
    }
}
