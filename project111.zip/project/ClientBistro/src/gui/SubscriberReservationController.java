package gui;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import logic.Subscriber;

import java.time.LocalDate;
import java.util.List;

public class SubscriberReservationController {

    @FXML private Label lblWelcome, lblGuests, lblName, lblEmail, lblPhone;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox<String> timeBox;
    @FXML private TextField txtConfirmationCode;

    private int guests = 2;
    private Subscriber currentSubscriber;
    private Order pendingOrder;

    private static SubscriberReservationController ACTIVE;

    @FXML
    public void initialize() {
        ACTIVE = this;

        lblGuests.setText(String.valueOf(guests));
        datePicker.setValue(LocalDate.now());

        timeBox.getItems().addAll(
                "17:00","17:30","18:00","18:30",
                "19:00","19:30","20:00","20:30","21:00","21:30"
        );
        timeBox.getSelectionModel().selectFirst();
    }

    public static SubscriberReservationController getActive() {
        return ACTIVE;
    }

    public void setSubscriber(Subscriber sub) {
        this.currentSubscriber = sub;
        lblWelcome.setText("Welcome back, " + sub.getUsername());
        lblName.setText(sub.getUsername());
        lblEmail.setText(sub.getEmail());
        lblPhone.setText(sub.getPhone());
    }

    @FXML
    private void incGuests() {
        if (guests < 10) guests++;
        lblGuests.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        lblGuests.setText(String.valueOf(guests));
    }

    /* ================= RESERVE ================= */
    @FXML
    private void onReserve() {

        Order order = new Order(
                0,
                datePicker.getValue().toString(),
                timeBox.getValue(),
                guests,
                0,
                currentSubscriber.getSubscriberId(),
                currentSubscriber.getPhone(),
                currentSubscriber.getEmail(),
                LocalDate.now().toString(),
                0,
                "BOOKED",
                null
        );

        pendingOrder = order;
        ClientUI.chat.sendToServer(new Request("CHECK_AVAILABILITY", order));
    }

    public void sendCreateReservation() {
        ClientUI.chat.sendToServer(new Request("CREATE_RESERVATION", pendingOrder));
    }

    public void showSuggestedTimes(List<String> times) {
        showInfo("No tables available.\nSuggested times:\n" + String.join(", ", times));
    }

    /* ================= CHECK IN ================= */
    @FXML
    private void onCheckIn() {

        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        try {
            int code = Integer.parseInt(txtConfirmationCode.getText().trim());
            ClientUI.chat.sendToServer(new Request("TERMINAL_CHECKIN", code));
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
        }
    }

    /* ================= BACK ================= */
    @FXML
    private void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));
            Parent root = loader.load();

            SubscriberMainController ctrl = loader.getController();
            ctrl.setClient(ClientUI.chat);
            ctrl.setSubscriber(currentSubscriber);

            Stage stage = (Stage) lblGuests.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= HELPERS ================= */
    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.showAndWait();
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.showAndWait();
    }
    public void handleCheckInSuccess(int tableNum, int code) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Check-In Successful");
        alert.setHeaderText("Welcome! Your table is ready ✅");
        alert.setContentText("Confirmation Code: " + code + "\nPlease go to Table #" + tableNum + ".\nEnjoy your meal!");
        alert.showAndWait();
    }

    public void handleCheckInWait() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("No Table Available Yet");
        alert.setHeaderText("Please wait a little bit ⏳");
        alert.setContentText("All matching tables are currently occupied.\nWe are working on it.\nAs soon as a table is free, we will notify you (SMS / Email).");
        alert.showAndWait();
    }

    public void handleCheckInError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Check-In Failed");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

}
