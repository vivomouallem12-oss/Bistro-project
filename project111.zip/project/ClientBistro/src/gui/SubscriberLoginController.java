package gui;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logic.SubscriberLoginRequest;

public class SubscriberLoginController {

    // ===== STATIC ACCESS FOR ChatClient =====
    private static SubscriberLoginController active;

    public SubscriberLoginController() {
        active = this;
    }

    public static SubscriberLoginController getActive() {
        return active;
    }

    // ===== FXML =====
    @FXML private TextField txtSubscriberId;
    @FXML private TextField txtSubscriberName;
    @FXML private Label lblStatus;

    // ===== LOGIN =====
    @FXML
    private void onLogin(ActionEvent event) {

        lblStatus.setText(""); // clear old message

        String id = txtSubscriberId.getText();
        String name = txtSubscriberName.getText();

        // validation
        if (id == null || id.isBlank() ||
            name == null || name.isBlank()) {
            lblStatus.setText("Please fill all fields");
            return;
        }

        try {
            Integer.parseInt(id);
        } catch (NumberFormatException e) {
            lblStatus.setText("Subscriber ID must be a number");
            return;
        }

        // send to server
        ClientUI.chat.sendToServer(
                new SubscriberLoginRequest(id.trim(), name.trim())
        );
    }

    // ===== CALLED FROM ChatClient ON LOGIN FAIL =====
    public void showLoginError() {
        lblStatus.setText("Wrong Subscriber ID or Name");
    }

    // ===== BACK =====
    @FXML
    private void onBack(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/RoleSelection.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage =
                    (Stage) ((Node) event.getSource())
                            .getScene().getWindow();
            currentStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
