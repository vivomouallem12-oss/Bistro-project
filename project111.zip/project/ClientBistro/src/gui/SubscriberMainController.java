package gui;

import client.ClientController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import logic.Subscriber;

public class SubscriberMainController {

    @FXML
    private Label lblWelcome;

    private ClientController client;

    // ✅ FULL SUBSCRIBER OBJECT
    private Subscriber subscriber;

    /* ================== INIT ================== */

    public void setClient(ClientController client) {
        this.client = client;
    }

    // ✅ CALLED FROM ChatClient AFTER LOGIN SUCCESS
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;

        lblWelcome.setText(
                "Welcome, " +
                subscriber.getUsername() +
                " (ID: " +
                subscriber.getSubscriberId() +
                ")"
        );
    }

    /* ================== BUTTONS ================== */

    @FXML
    private void onMakeReservation(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberReservation.fxml"));
            Parent root = loader.load();

            SubscriberReservationController ctrl =
                    loader.getController();

            // ✅ PASS THE SUBSCRIBER OBJECT ONLY
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("Make a Reservation");
            stage.setScene(new Scene(root));
            stage.show();

            // close current window
            Stage current =
                    (Stage) ((Node) event.getSource())
                            .getScene().getWindow();
            current.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onJoinWaitingList(ActionEvent event) {
        showNotReady();
    }

    @FXML
    private void onPayBill(ActionEvent event) {
        showNotReady();
    }

    @FXML
    private void onMyAccount(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/AccountHistory.fxml"));
            Parent root = loader.load();

            AccountHistoryController ctrl =
                    loader.getController();

            ctrl.setClient(client);
            ctrl.setSubscriber(subscriber); // ✅ FIXED

            Stage stage = new Stage();
            stage.setTitle("My Account History");
            stage.setScene(new Scene(root));
            stage.show();

            Stage current =
                    (Stage) ((Node) event.getSource())
                            .getScene().getWindow();
            current.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void onLogout(ActionEvent event) {
        System.exit(0);
    }

    /* ================== HELPERS ================== */

    private void showNotReady() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Not Ready");
        alert.setHeaderText(null);
        alert.setContentText("This feature is not implemented yet.");
        alert.showAndWait();
    }
}
