package gui;

import client.ClientController;
import javafx.application.Platform;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import logic.*;

import java.util.ArrayList;
import java.util.List;

public class AccountHistoryController implements SubscriberChildScreen {

    @FXML private TableView<Order> reservationsTable;
    @FXML private TableView<VisitHistory> visitsTable;

    @FXML private TableColumn<Order, Integer> colResId;
    @FXML private TableColumn<Order, String> colResDate;
    @FXML private TableColumn<Order, Integer> colGuests;
    @FXML private TableColumn<Order, String> colResStatus;

    @FXML private TableColumn<VisitHistory, String> colVisitDate;
    @FXML private TableColumn<VisitHistory, Integer> colVisitPeople;
    @FXML private TableColumn<VisitHistory, String> colVisitStatus;

    @FXML private Button btnBack;

    private ClientController client;
    private Subscriber subscriber;

    private static AccountHistoryController ACTIVE;

    @FXML
    public void initialize() {
        ACTIVE = this;

        colResId.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getOrder_number()).asObject());

        colResDate.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_date()));

        colGuests.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getNumber_of_guests()).asObject());

        colResStatus.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_status()));

        colVisitDate.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getVisitDate()));

        colVisitPeople.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getPeople()).asObject());

        colVisitStatus.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getStatus()));

        btnBack.setOnAction(e -> goBack());
    }

    public static AccountHistoryController getActive() {
        return ACTIVE;
    }

    @Override
    public void setClient(ClientController client) {
        this.client = client;
    }

    @Override
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
        if (client != null && subscriber != null) {
            client.sendToServer(
                    new Request("GET_ACCOUNT_HISTORY", subscriber.getSubscriberId())
            );
        }
    }

    public void handleAccountHistoryOrders(List<Order> orders) {

        List<Order> reservations = new ArrayList<>();
        List<VisitHistory> visits = new ArrayList<>();

        for (Order o : orders) {
            reservations.add(o);

            if ("COMPLETED".equalsIgnoreCase(o.getOrder_status())) {
                visits.add(new VisitHistory(
                        o.getOrder_date(),
                        o.getNumber_of_guests(),
                        o.getOrder_status()
                ));
            }
        }

        Platform.runLater(() -> {
            reservationsTable.setItems(
                    FXCollections.observableArrayList(reservations)
            );
            visitsTable.setItems(
                    FXCollections.observableArrayList(visits)
            );
        });
    }

    private void goBack() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));

            Parent root = loader.load();

            SubscriberMainController ctrl = loader.getController();
            ctrl.setClient(client);
            ctrl.setSubscriber(subscriber);

            Stage stage = (Stage) btnBack.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
