package gui;

import javafx.fxml.FXML;
import javafx.scene.chart.*;

public class ReportsAnalysisController {

    @FXML
    private LineChart<String, Number> arrivalChart;

    @FXML
    private BarChart<String, Number> reservationChart;

    @FXML
    public void initialize() {
        loadArrivalReport();
        loadReservationReport();
    }

    private void loadArrivalReport() {
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Average Delay");

        series.getData().add(new XYChart.Data<>("Week 1", 5));
        series.getData().add(new XYChart.Data<>("Week 2", 8));
        series.getData().add(new XYChart.Data<>("Week 3", 4));
        series.getData().add(new XYChart.Data<>("Week 4", 6));

        arrivalChart.getData().add(series);
    }

    private void loadReservationReport() {
        XYChart.Series<String, Number> reservations = new XYChart.Series<>();
        reservations.setName("Reservations");

        XYChart.Series<String, Number> waitingList = new XYChart.Series<>();
        waitingList.setName("Waiting List");

        reservations.getData().add(new XYChart.Data<>("Week 1", 42));
        reservations.getData().add(new XYChart.Data<>("Week 2", 55));
        reservations.getData().add(new XYChart.Data<>("Week 3", 48));
        reservations.getData().add(new XYChart.Data<>("Week 4", 61));

        waitingList.getData().add(new XYChart.Data<>("Week 1", 10));
        waitingList.getData().add(new XYChart.Data<>("Week 2", 14));
        waitingList.getData().add(new XYChart.Data<>("Week 3", 9));
        waitingList.getData().add(new XYChart.Data<>("Week 4", 12));

        reservationChart.getData().addAll(reservations, waitingList);
    }
}
