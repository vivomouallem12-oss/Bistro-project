package gui;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;

public class WaitingListController {

    @FXML
    private TableView<?> waitingTable;

}
