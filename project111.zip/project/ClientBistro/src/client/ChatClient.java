package client;

import ocsf.client.AbstractClient;
import common.ChatIF;
import gui.AccountHistoryController;
import gui.ReservationController;
import gui.SubscriberMainController;
import gui.SubscriberReservationController;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import logic.*;

import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ChatClient extends AbstractClient {

    /* ================= INSTANCE VARIABLES ================= */
    private ChatIF clientUI;

    /* ===== CALLBACKS ===== */
    public static Consumer<List<Order>> ordersListCallback = null;
    public static Consumer<List<VisitHistory>> visitsListCallback = null;

    /* ===== VISIT BUFFER (legacy support) ===== */
    private static final List<VisitHistory> visitBuffer = new ArrayList<>();
    private static String pendingVisitDate = null;
    private static Integer pendingVisitPeople = null;

    public ChatClient(String host, int port, ChatIF clientUI) throws IOException {
        super(host, port);
        this.clientUI = clientUI;
    }

    /* ================== SERVER MESSAGES =================== */
    @Override
    public void handleMessageFromServer(Object msg) {

        /* =================================================
           RESPONSE OBJECTS
           ================================================= */
        if (msg instanceof Response r) {

            String status = r.getStatus();

            switch (status) {

                /* ---------- GUEST RESERVATION ---------- */
                case "FREE_TABLES_FOUND" -> Platform.runLater(() ->
                        ReservationController.getInstance()
                                .handleFreeTables((List<Tables>) r.getData())
                );

                case "FREE_TABLES_NOT_FOUND" -> Platform.runLater(() ->
                        ReservationController.getInstance()
                                .orderFail("No tables found at this time.", (List<LocalTime>)r.getData())
                );

                case "CODE_FOUND" -> Platform.runLater(() ->
                        ReservationController.getInstance()
                                .codeSuccess((OrderCustomer) r.getData())
                );

                case "CODE_NOT_FOUND" -> Platform.runLater(() -> {
                    SubscriberReservationController subCtrl =
                            SubscriberReservationController.getActive();
                    if (subCtrl != null) {
                        subCtrl.handleCheckInError("Reservation code not found.");
                    } else {
                        ReservationController.getInstance()
                                .codeStatus("Reservation code not found.", "red");
                    }
                });

                case "CANCEL_SUCCESS" -> Platform.runLater(() ->
                        ReservationController.getInstance()
                                .codeStatus("Order canceled.", "red")
                );

                case "PAYMENT_SUCCESS" -> Platform.runLater(() ->
                        ReservationController.getInstance()
                                .codeStatus("Payment completed.", "green")
                );

                /* ---------- SUBSCRIBER RESERVATION ---------- */
                case "AVAILABLE" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) ctrl.sendCreateReservation();
                });

                case "NOT_AVAILABLE" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) ctrl.showSuggestedTimes((List<String>) r.getData());
                });

                case "RESERVATION_CREATED" -> Platform.runLater(() -> {
                    Map<String, Object> data = (Map<String, Object>) r.getData();
                    int code = (int) data.get("confirmationCode");

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Reservation Confirmed");
                    alert.setHeaderText("Reservation successful ✅");
                    alert.setContentText("Your confirmation code is:\n" + code);
                    alert.showAndWait();
                });

                /* ---------- CHECK-IN (SUBSCRIBER TERMINAL) ---------- */
                case "CHECKIN_SUCCESS" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) {
                        Map<String, Object> data = (Map<String, Object>) r.getData();
                        int tableNum = (int) data.get("table_num");
                        int code = (int) data.get("confirmation_code");
                        ctrl.handleCheckInSuccess(tableNum, code);
                    }
                });

                case "NO_TABLE_AVAILABLE" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) {
                        ctrl.handleCheckInWait();
                    }
                });

                case "CHECKIN_NOT_ALLOWED" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) {
                        ctrl.handleCheckInError(
                                "Check-in not allowed.\nCurrent status: " + r.getData()
                        );
                    }
                });

                /* ---------- ACCOUNT HISTORY ---------- */
                case "ACCOUNT_HISTORY" -> Platform.runLater(() -> {
                    AccountHistoryController ctrl =
                            AccountHistoryController.getActive();
                    if (ctrl != null) {
                        ctrl.handleAccountHistoryOrders((List<Order>) r.getData());
                    }
                });

                default -> System.out.println("[Client] Unhandled Response: " + status);
            }
            return;
        }

        /* =================================================
           LOGIN SUCCESS
           ================================================= */
        if (msg instanceof Subscriber sub) {
            Platform.runLater(() -> {
                try {
                    FXMLLoader loader =
                            new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));

                    Parent root = loader.load();

                    SubscriberMainController ctrl = loader.getController();
                    ctrl.setClient(ClientUI.chat);
                    ctrl.setSubscriber(sub);

                    Stage stage = new Stage();
                    stage.setScene(new Scene(root));
                    stage.show();

                    javafx.stage.Window.getWindows().forEach(w -> {
                        if (w instanceof Stage s2 && s2 != stage) {
                            s2.close();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            return;
        }

        /* =================================================
           GENERIC STRING
           ================================================= */
        if (msg instanceof String response) {
            System.out.println("[Client] Server: " + response);
            if (clientUI != null)
                clientUI.display(response);
        }
    }

    /* ================= CLIENT → SERVER ================= */
    public void handleMessageFromClientUI(Object message) {
        try {
            openConnection();
            sendToServer(message);
        } catch (IOException e) {
            e.printStackTrace();
            if (clientUI != null) {
                clientUI.display("Could not send message to server.");
            }
            quit();
        }
    }

    public void quit() {
        try {
            closeConnection();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
}
