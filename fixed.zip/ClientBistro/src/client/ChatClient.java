package client;

import common.ChatIF;
import gui.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import logic.*;
import navigation.Navigation;
import ocsf.client.AbstractClient;

import java.io.IOException;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ChatClient extends AbstractClient {

    /* ================= INSTANCE VARIABLES ================= */
    private final ChatIF clientUI;

    // ✅ Global “session” for THIS CLIENT APP only (no extra classes)
    private static Subscriber activeSubscriber = null;

    private static PaymentController activePaymentController;
    private static ReservationHandler activeReservationHandler;

    /* ================= CALLBACKS ================= */
    public static Consumer<List<Order>> ordersListCallback = null;
    public static Consumer<List<VisitHistory>> visitsListCallback = null;

    public ChatClient(String host, int port, ChatIF clientUI) throws IOException {
        super(host, port);
        this.clientUI = clientUI;
    }

    /* ================= ACTIVE SUBSCRIBER (THIS CLIENT) ================= */

    public static void setActiveSubscriber(Subscriber sub) {
        activeSubscriber = sub;
    }

    public static Subscriber getActiveSubscriber() {
        return activeSubscriber;
    }

    /* ================= ACTIVE CONTROLLERS ================= */

    public static void setActivePaymentController(PaymentController ctrl) {
        activePaymentController = ctrl;
    }

    public static void setActiveReservationHandler(ReservationHandler handler) {
        activeReservationHandler = handler;
    }

    public static ReservationHandler getActiveReservationHandler() {
        return activeReservationHandler;
    }

    /* ================= SERVER → CLIENT ================= */
    @Override
    public void handleMessageFromServer(Object msg) {

        System.out.println("[SERVER → CLIENT] " + (msg == null ? "null" : msg.getClass().getSimpleName()));

        /* ================= RESPONSE ================= */
        if (msg instanceof Response r) {

            String status = r.getStatus();
            System.out.println("[RESPONSE] status=" + status);

            switch (status) {

                /* ---------- GUEST RESERVATION ---------- */
                case "FREE_TABLES_FOUND" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.handleFreeTables((int) r.getData());
                });

                case "FREE_TABLES_NOT_FOUND" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.orderFail("No tables found at this time.", (List<LocalTime>) r.getData());
                });

                case "ENTER_WAITING" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.handleFreeTables(0);
                });

                case "CODE_FOUND" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.codeSuccess((OrderCustomer) r.getData());
                });

                case "CODE_NOT_FOUND" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.codeStatus("Reservation code not found.", "red");
                });

                case "CHECK_IN" -> Platform.runLater(() -> {
                    ReservationHandler h = ChatClient.getActiveReservationHandler();
                    if (h != null)
                        h.codeStatus("Welcome, You can sit at table " + r.getData() + "!", "green");
                });

                /* ---------- MANAGER / AGENT FEATURES ---------- */
                case "CURRENT_CUSTOMERS_LIST" -> Platform.runLater(() -> {
                    if (gui.CurrentCustomersController.activeController != null) {
                        gui.CurrentCustomersController.activeController
                                .setCustomers((List<Order>) r.getData());
                    }
                });

                case "ACTIVE_RESERVATIONS_LIST" -> Platform.runLater(() -> {
                    if (gui.ActiveReservationsController.activeController != null) {
                        gui.ActiveReservationsController.activeController
                                .setReservations((List<Order>) r.getData());
                    }
                });

                case "SUBSCRIBERS_LIST" -> Platform.runLater(() -> {
                    if (SubscribersListController.activeController != null) {
                        SubscribersListController.activeController
                                .setSubscribers((List<Subscriber>) r.getData());
                    }
                });

                case "STAFF_LOGIN_SUCCESS" -> Platform.runLater(() -> {
                    Staff staff = (Staff) r.getData();
                    try {
                        if (staff.getRole().equals("MANAGER")) {
                            Navigation.setRole(Navigation.Role.MANAGER);
                            ManagerLoginController.getActive().showLoginSuccess();
                        } else {
                            Navigation.setRole(Navigation.Role.AGENT);
                            RepresentativeLoginController.getActive().showLoginSuccess();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });

                case "LOGIN_FAIL" -> Platform.runLater(() -> {
                    if (gui.ManagerLoginController.getActive() != null) {
                        gui.ManagerLoginController.getActive().showLoginError();
                    }
                });

                case "OPENING_HOURS_UPDATED" -> Platform.runLater(() ->
                        showInfo("Opening hours updated successfully ✅")
                );

                case "TABLES_LIST" -> Platform.runLater(() -> {
                    if (gui.TablesManagementController.activeController != null) {
                        gui.TablesManagementController.activeController
                                .setTables((List<Tables>) r.getData());
                    }
                });

                case "TABLE_ADDED" -> Platform.runLater(() -> showInfo("Table added successfully ✅"));
                case "TABLE_DELETED" -> Platform.runLater(() -> showInfo("Table deleted successfully ✅"));
                case "TABLE_UPDATED" -> Platform.runLater(() -> showInfo("Table updated successfully ✅"));

                case "ALL_RESERVATIONS_LIST" -> Platform.runLater(() -> {
                    if (gui.ViewReservationsController.activeController != null) {
                        gui.ViewReservationsController.activeController
                                .setReservations((List<Order>) r.getData());
                    }
                });

                case "SUBSCRIBER_CREATED" -> Platform.runLater(() -> {
                    int id = (int) r.getData();
                    String displayId = String.format("%04d", id);

                    if (gui.RegisterSubscriberController.activeController != null) {
                        gui.RegisterSubscriberController.activeController
                                .showSuccess(displayId);
                    }
                });

                case "MANAGEMENT_INFO" -> Platform.runLater(() -> {
                    Map<String, Integer> data = (Map<String, Integer>) r.getData();

                    if (gui.ManagementInfoController.activeController != null) {
                        gui.ManagementInfoController.activeController.updateData(
                                data.get("today"),
                                data.get("month"),
                                data.get("canceled"),
                                data.get("subscribers"),
                                data.get("inside")
                        );
                    }
                });

                case "REPORTS_DATA" -> Platform.runLater(() -> {
                    if (gui.ReportsAnalysisController.activeController != null) {
                        gui.ReportsAnalysisController.activeController
                                .setReportsData((Map<String, Map<String, Integer>>) r.getData());
                    }
                });

                case "CANCEL_SUCCESS" -> Platform.runLater(() -> {

                    SubscriberReservationController subCtrl =
                            SubscriberReservationController.getActive();

                    if (subCtrl != null) {
                        subCtrl.codeStatus("Order canceled.", "red");
                        return;
                    }

                    ReservationController resCtrl =
                            ReservationController.getInstance();

                    if (resCtrl != null) {
                        resCtrl.codeStatus("Order canceled.", "red");
                    }
                });

                case "CANCEL_FAILED" -> Platform.runLater(() -> {

                    SubscriberReservationController subCtrl =
                            SubscriberReservationController.getActive();

                    if (subCtrl != null) {
                        subCtrl.codeStatus("Cancel failed.", "red");
                        return;
                    }

                    ReservationController resCtrl =
                            ReservationController.getInstance();

                    if (resCtrl != null) {
                        resCtrl.codeStatus("Cancel failed.", "red");
                    }
                });

                /* ---------- PAYMENT ---------- */
                case "ORDER_PAYABLE" -> Platform.runLater(() -> {

                    // Keep your behavior: close the "enter code" window if it's open
                    EntryPaymentCodeController epc = EntryPaymentCodeController.getActive();
                    if (epc != null) epc.closeWindow();

                    Map<?, ?> data = (Map<?, ?>) r.getData();
                    int confirmationCode = (int) data.get("confirmationCode");
                    double price = (double) data.get("price");

                    // ✅ Subscriber comes from ChatClient "session" (no extra classes)
                    Subscriber sub = ChatClient.getActiveSubscriber();

                    openPaymentWindow(sub, confirmationCode, price);
                });

                case "ORDER_NOT_PAYABLE" -> Platform.runLater(() ->
                        showError("Payment not allowed.\nStatus: " + r.getData())
                );

                case "PAYMENT_SUCCESS" -> Platform.runLater(() -> {
                    if (activePaymentController != null)
                        activePaymentController.showPaymentSuccess();
                });

                case "PAYMENT_FAILED" -> Platform.runLater(() -> {
                    if (activePaymentController != null)
                        activePaymentController.showPaymentFailed();
                });

                /* ---------- SUBSCRIBER RESERVATION ---------- */
                case "AVAILABLE" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.sendCreateReservation();
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        appCtrl.sendCreateReservation();
                    }
                });

                case "NOT_AVAILABLE" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.showSuggestedTimes((List<LocalTime>) r.getData());
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        appCtrl.showSuggestedTimes((List<LocalTime>) r.getData());
                    }
                });

                case "RESERVATION_CREATED" -> Platform.runLater(() -> {
                    int code = (int) ((Map<?, ?>) r.getData()).get("confirmationCode");
                    showInfo("Reservation confirmed successfully and confirmation code sent to email\nConfirmation code: " + code);
                });

                case "LOST_CODE_SENT" -> Platform.runLater(() ->
                        showInfo("Your reservation codes were sent to your email.")
                );

                case "LOST_CODE_FAILED" -> Platform.runLater(() -> {
                    showError(
                            "❌ No active reservations found.\n\n" +
                                    "You currently don't have any upcoming bookings,\n" +
                                    "or your reservations were already cancelled.\n\n" +
                                    "Please make a new reservation if needed."
                    );
                });

                /* ---------- CHECK-IN ---------- */
                case "CHECKIN_SUCCESS" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) {
                        Map<?, ?> data = (Map<?, ?>) r.getData();
                        ctrl.handleCheckInSuccess(
                                (int) data.get("table_num"),
                                (int) data.get("confirmation_code")
                        );
                    }
                });

                case "NO_TABLE_AVAILABLE" -> Platform.runLater(() -> {
                    SubscriberReservationController ctrl =
                            SubscriberReservationController.getActive();
                    if (ctrl != null) ctrl.handleCheckInWait();
                });

                case "CHECKIN_CODE_NOT_FOUND" ->
                        Platform.runLater(() -> showError("Confirmation code not found."));

                case "CHECKIN_WRONG_DAY" ->
                        Platform.runLater(() -> showError("This reservation is not for today."));

                case "CHECKIN_TOO_EARLY" ->
                        Platform.runLater(() -> showError("You arrived too early."));

                case "CHECKIN_TOO_LATE" ->
                        Platform.runLater(() -> showError("You arrived too late."));

                case "CHECKIN_NOT_ALLOWED" ->
                        Platform.runLater(() -> showError("Check-in not allowed.\n" + r.getData()));

                /* ---------- WAITING LIST ---------- */
                case "WAITING_SEATED" -> Platform.runLater(() -> {
                    Map<?, ?> data = (Map<?, ?>) r.getData();
                    showInfo(
                            "🎉 Table is ready!\n\n" +
                                    "Table Number: " + data.get("table_num") + "\n" +
                                    "Confirmation Code: " + data.get("confirmationCode")
                    );
                });

                case "WAITING_JOINED" -> Platform.runLater(() -> {
                    int code = (int) ((Map<?, ?>) r.getData()).get("confirmationCode");
                    showInfo(
                            "✅ You have been added to the waiting list.\n\n" +
                                    "Confirmation Code: " + code + "\n\n" +
                                    "⏳ When a table becomes available, you will receive an email.\n" +
                                    "Please wait patiently. Thank you!"
                    );
                });

                case "WAITING_ALREADY_EXISTS" -> Platform.runLater(() -> {
                    int code = (int) ((Map<?, ?>) r.getData()).get("confirmationCode");
                    showInfo("ℹ Already in waiting list.\nCode: " + code);
                });

                case "WAITING_NOT_ALLOWED" ->
                        Platform.runLater(() -> showError((String) r.getData()));

                case "WAITING_LEFT" ->
                        Platform.runLater(() -> showInfo("✅ Left waiting list."));

                case "WAITING_NOT_FOUND" ->
                        Platform.runLater(() -> showError("Waiting entry not found."));

                case "WAITING_JOIN_FAILED" ->
                        Platform.runLater(() -> showError("Failed to join waiting list."));

                /* ---------- ACCOUNT HISTORY ---------- */
                case "ACCOUNT_VISITS" -> Platform.runLater(() -> {
                    AccountHistoryController ctrl = AccountHistoryController.getActive();
                    if (ctrl != null)
                        ctrl.handleVisitHistory((List<Order>) r.getData());
                });

                case "ACCOUNT_RESERVATIONS" -> Platform.runLater(() -> {
                    AccountHistoryController ctrl = AccountHistoryController.getActive();
                    if (ctrl != null)
                        ctrl.handleReservationHistory((List<Order>) r.getData());
                });

                /* ---------- SUBSCRIBER UPDATE DETAILS ---------- */
                case "UPDATE_EMAIL_SUCCESS" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.applyUpdatedEmail((String) r.getData());
                        termCtrl.codeStatus("Email updated successfully ✅", "green");
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        appCtrl.applyUpdatedEmail((String) r.getData());
                        showInfo("Email updated successfully ✅");
                    }
                });

                case "UPDATE_EMAIL_FAILED" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.codeStatus("Failed to update email ❌", "red");
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        showError("Failed to update email ❌");
                    }
                });

                case "UPDATE_PHONE_SUCCESS" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.applyUpdatedPhone((String) r.getData());
                        termCtrl.codeStatus("Phone updated successfully ✅", "green");
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        appCtrl.applyUpdatedPhone((String) r.getData());
                        showInfo("Phone updated successfully ✅");
                    }
                });

                case "UPDATE_PHONE_FAILED" -> Platform.runLater(() -> {

                    // Terminal
                    SubscriberReservationController termCtrl =
                            SubscriberReservationController.getActive();
                    if (termCtrl != null) {
                        termCtrl.codeStatus("Failed to update phone ❌", "red");
                        return;
                    }

                    // App
                    SubscriberReservationAppController appCtrl =
                            SubscriberReservationAppController.getActive();
                    if (appCtrl != null) {
                        showError("Failed to update phone ❌");
                    }
                });

                /* ---------- SUBSCRIBER LOGIN ---------- */
                case "SUBSCRIBER_LOGIN_SUCCESS" -> Platform.runLater(() -> {
                    try {
                        Subscriber sub = (Subscriber) r.getData();

                        // ✅ Save subscriber for payment + other screens
                        ChatClient.setActiveSubscriber(sub);

                        loadSubscriberMain(sub);
                    } catch (Exception e) {
                        e.printStackTrace();
                        showError("Login succeeded but failed to open SubscriberMain.");
                    }
                });

                case "SUBSCRIBER_LOGIN_FAIL" -> Platform.runLater(() -> {
                    if (SubscriberLoginController.getActive() != null) {
                        SubscriberLoginController.getActive()
                                .showCustomError("Wrong Subscriber ID or Name");
                    }
                });

                default -> System.out.println("[Client] Unhandled Response: " + status);
            }
            return;
        }

        /* ================= LOGIN (Fallback) ================= */
        if (msg instanceof Subscriber sub) {
            Platform.runLater(() -> {
                // ✅ Save subscriber for payment + other screens
                ChatClient.setActiveSubscriber(sub);

                loadSubscriberMain(sub);
            });
            return;
        }

        /* ================= ERROR ================= */
        if ("SERVER_ERROR".equals(msg)) {
            Platform.runLater(() ->
                    showError("Server error. Please try again later."));
        }
    }

    /* ================= HELPERS ================= */

    private void openPaymentWindow(Subscriber sub, int confirmationCode, double price) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/Payment.fxml"));
            Parent root = loader.load();

            PaymentController ctrl = loader.getController();

            // ✅ Subscriber is always passed (if logged-in)
            ctrl.setData(sub, confirmationCode, price);

            Stage stage = new Stage();
            stage.setTitle("Payment");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSubscriberMain(Subscriber sub) {
        try {

            String fxml;
            if (navigation.Navigation.getRoleSelectionScreen().equals("RoleSelectionTerminal.fxml")) {
                fxml = "/gui/SubscriberMain.fxml";    // Terminal
            } else {
                fxml = "/gui/SubscriberMainApp.fxml"; // App
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            if (fxml.contains("App")) {
                SubscriberMainControllerApp ctrl = loader.getController();
                ctrl.setSubscriber(sub);
            } else {
                SubscriberMainController ctrl = loader.getController();
                ctrl.setSubscriber(sub);
            }

            Stage stage = new Stage();
            stage.setTitle("Subscriber Dashboard");
            stage.setScene(new Scene(root));
            stage.show();

            // ✅ CLOSE LOGIN WINDOW
            Platform.runLater(() -> {
                if (SubscriberLoginController.getActive() != null) {
                    Stage loginStage =
                            (Stage) SubscriberLoginController.getActive()
                                    .getTxtSubscriberId().getScene().getWindow();
                    loginStage.close();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Called by ClientController.accept(...) in your project.
     * FIXED: do NOT open/close socket here and do NOT quit() on error (EOFException on server).
     */
    public void handleMessageFromClientUI(Object message) {
        try {
            sendToServer(message);
        } catch (IOException e) {
            e.printStackTrace();
            Platform.runLater(() -> showError("Failed to send message to server."));
        }
    }

    public void quit() {
        try {
            closeConnection();
        } catch (IOException ignored) {
        }
    }

    private static void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }

    private static void showInfo(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
}
