package gui;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Scene;
import navigation.Navigation;

public class RoleSelectionTerminalController {

    @FXML
    private AnchorPane anchorPane;

    @FXML private StackPane guestCard;
    @FXML private StackPane subscriberCard;
    @FXML private StackPane agentCard;
    @FXML private StackPane managerCard;
    @FXML private Button exitBtn, backBtn;

    @FXML
    public void initialize() {
        applyHoverEffect(guestCard);
        applyHoverEffect(subscriberCard);
        applyHoverEffect(agentCard);
        applyHoverEffect(managerCard);

        // 🔥 IMPORTANT: Set TERMINAL mode
        Navigation.setMode(Navigation.Mode.TERMINAL);
    }

    // ==================================================
    //                    ROLE ROUTING
    // ==================================================

    /**
     * GUEST FLOW
     * RoleSelectionTerminal -> TerminalReservation.fxml
     */
    @FXML
    private void onGuestClicked() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/TerminalReservation.fxml"));
            Parent root = loader.load();

            TerminalReservationController controller = loader.getController();
            controller.setClient(ClientUI.chat); // Inject client

            anchorPane.getScene().setRoot(root);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * SUBSCRIBER FLOW
     * RoleSelectionTerminal -> SubscriberLogin.fxml
     */
    @FXML
    private void onSubscriberClicked() {
        loadScreen("SubscriberLogin.fxml");
    }

    /**
     * AGENT FLOW
     */
    @FXML
    private void onAgentClicked() {
        loadScreen("RepresentativeLogin.fxml");
    }

    /**
     * MANAGER FLOW
     */
    @FXML
    private void onManagerClicked() {
        loadScreen("ManagerLogin.fxml");
    }

    // ==================================================
    //                    HELPERS
    // ==================================================

    /**
     * Generic screen loader
     */
    private void loadScreen(String fxml) {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + fxml)
            );
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Card hover animation
     */
    private void applyHoverEffect(StackPane card) {
        card.setOnMouseEntered(e -> {
            card.setScaleX(1.05);
            card.setScaleY(1.05);
        });

        card.setOnMouseExited(e -> {
            card.setScaleX(1.0);
            card.setScaleY(1.0);
        });
    }

    /* ================= BACK ================= */
    @FXML
    private void back() {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/Interface.fxml")
            );
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= EXIT ================= */
    @FXML
    private void exit() {
        System.exit(0);
    }
}
