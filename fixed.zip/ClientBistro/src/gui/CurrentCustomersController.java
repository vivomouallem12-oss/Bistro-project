package gui;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import navigation.Navigation;

import java.util.List;

public class CurrentCustomersController {

    public static CurrentCustomersController activeController;

    public CurrentCustomersController() {
        activeController = this;
    }

    @FXML private TableView<Order> table;
    @FXML private TableColumn<Order, Integer> colTable;
    @FXML private TableColumn<Order, Integer> colGuests;
    @FXML private TableColumn<Order, String> colTime;
    @FXML private Button backBtn, exitBtn;

    @FXML
    public void initialize() {
        colTable.setCellValueFactory(new PropertyValueFactory<>("table_num"));
        colGuests.setCellValueFactory(new PropertyValueFactory<>("number_of_guests"));
        colTime.setCellValueFactory(new PropertyValueFactory<>("order_time"));

        ClientUI.chat.sendToServer(
            new Request("GET_CURRENT_CUSTOMERS", null)
        );
    }

    public void setCustomers(List<Order> list) {
        table.getItems().setAll(list);
    }

    /* ================= EXIT ================= */
    @FXML
    private void exit() {
        System.exit(0);
    }

    /* ================= BACK (ROLE-BASED) ================= */
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getHomeByRole(); // Manager or Agent home
            System.out.println("BACK TO: " + target);

            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + target)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
