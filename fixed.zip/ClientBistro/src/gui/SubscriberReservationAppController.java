package gui;

import client.ClientUI;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import logic.Subscriber;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// 🔧 ONLY CHANGE: implements SubscriberChildScreen
public class SubscriberReservationAppController implements SubscriberChildScreen {

    @FXML private Label lblWelcome, lblGuests, lblName, lblEmail, lblPhone;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox<String> timeBox;
    @FXML private TextField txtConfirmationCode;

    private int guests = 2;
    private Subscriber currentSubscriber;
    private Order pendingOrder;

    private static SubscriberReservationAppController ACTIVE;

    private final DateTimeFormatter timeFormatter =
            DateTimeFormatter.ofPattern("HH:mm");

    /* ================= INIT ================= */
    @FXML
    public void initialize() {
        ACTIVE = this;

        lblGuests.setText(String.valueOf(guests));
        datePicker.setValue(LocalDate.now());

        timeBox.getItems().addAll(
                "17:00","17:30","18:00","18:30",
                "19:00","19:30","20:00","20:30","21:00","21:30"
        );

        timeBox.getSelectionModel().selectFirst();
    }

    public static SubscriberReservationAppController getActive() {
        return ACTIVE;
    }

    /* ================= SUBSCRIBER ================= */
    @Override
    public void setSubscriber(Subscriber sub) {
        this.currentSubscriber = sub;

        if (sub == null) return;

        lblWelcome.setText("Welcome back, " + sub.getUsername());
        lblName.setText(sub.getUsername());
        lblEmail.setText(sub.getEmail());
        lblPhone.setText(sub.getPhone());
    }

    @Override
    public void setClient(client.ClientController client) {
        // Not needed in App mode
    }

    /* ================= GUESTS ================= */
    @FXML
    private void incGuests() {
        if (guests < 10) guests++;
        lblGuests.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        lblGuests.setText(String.valueOf(guests));
    }

    /* ================= RESERVE ================= */
    @FXML
    private void onReserve() {

        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        Order order = new Order(
                0,
                datePicker.getValue().toString(),
                timeBox.getValue(),
                guests,
                0,
                currentSubscriber.getSubscriberId(),
                currentSubscriber.getPhone(),
                currentSubscriber.getEmail(),
                LocalDate.now().toString(),
                0,
                "BOOKED",
                null
        );

        pendingOrder = order;

        ClientUI.chat.sendToServer(
                new Request("CHECK_AVAILABILITY", order)
        );
    }

    public void sendCreateReservation() {
        if (pendingOrder == null) {
            showError("No pending order found. Please click Reserve again.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("CREATE_RESERVATION", pendingOrder)
        );
    }

    /* ================= CANCEL ================= */
    @FXML
    private void onCancelReservation() {

        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        int code;
        try {
            code = Integer.parseInt(txtConfirmationCode.getText().trim());
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Cancel Reservation");
        confirm.setHeaderText("Are you sure?");
        confirm.setContentText("Confirmation Code: " + code);

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK)
            return;

        ClientUI.chat.sendToServer(
                new Request("CANCEL_ORDER", code)
        );
    }

    /* ================= LOST CODE ================= */
    @FXML
    private void onForgotConfirmationCode() {

        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("LOST_CONFIRMATION_CODE",
                        currentSubscriber.getSubscriberId())
        );
    }

    /* ================= SUGGESTED TIMES ================= */
    public void showSuggestedTimes(List<LocalTime> times) {

        Platform.runLater(() -> {

            if (times == null || times.isEmpty()) {
                showInfo("Sorry, no tables are available at your selected time.");
                return;
            }

            String timesStr = times.stream()
                    .map(t -> t.format(timeFormatter))
                    .collect(Collectors.joining(", "));

            showInfo("No tables available at your selected time.\nSuggested times:\n" + timesStr);
        });
    }

    /* ================= BACK ================= */
    @FXML
    private void onBack() {

        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberMainApp.fxml"));
            Parent root = loader.load();

            SubscriberMainControllerApp ctrl = loader.getController();
            ctrl.setSubscriber(currentSubscriber);

            Stage stage = (Stage) lblGuests.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= EDIT ================= */
    @FXML
    private void onEditPhone() {

        TextInputDialog dialog = new TextInputDialog(lblPhone.getText());
        dialog.setTitle("Edit Phone");

        dialog.showAndWait().ifPresent(newPhone -> {

            if (!newPhone.matches("\\d{9,10}")) {
                showError("Invalid phone number.");
                return;
            }

            ClientUI.chat.sendToServer(
                    new Request("UPDATE_SUBSCRIBER_PHONE",
                            Map.of("subscriberId", currentSubscriber.getSubscriberId(),
                                   "phone", newPhone))
            );
        });
    }

    @FXML
    private void onEditEmail() {

        TextInputDialog dialog = new TextInputDialog(lblEmail.getText());
        dialog.setTitle("Edit Email");

        dialog.showAndWait().ifPresent(newEmail -> {

            if (!newEmail.contains("@")) {
                showError("Invalid email.");
                return;
            }

            ClientUI.chat.sendToServer(
                    new Request("UPDATE_SUBSCRIBER_EMAIL",
                            Map.of("subscriberId", currentSubscriber.getSubscriberId(),
                                   "email", newEmail))
            );
        });
    }

    public void applyUpdatedEmail(String newEmail) {
        lblEmail.setText(newEmail);
        currentSubscriber.setEmail(newEmail);
    }

    public void applyUpdatedPhone(String newPhone) {
        lblPhone.setText(newPhone);
        currentSubscriber.setPhone(newPhone);
    }

    /* ================= HELPERS ================= */
    private void showError(String msg) {
        new Alert(Alert.AlertType.ERROR, msg).showAndWait();
    }

    private void showInfo(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }
}
