package gui;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import logic.Request;
import logic.Subscriber;
import logic.SubscriberLoginRequest;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.imageio.ImageIO;
import java.io.File;

public class SubscriberLoginController {

    private static SubscriberLoginController active;

    public SubscriberLoginController() {
        active = this;
    }

    public static SubscriberLoginController getActive() {
        return active;
    }

    @FXML private TextField txtSubscriberId;
    @FXML private TextField txtSubscriberName;
    @FXML private Label lblStatus;

    /* ================= INIT ================= */
    @FXML
    public void initialize() {
        lblStatus.setText("");   // no default message
    }

    /* ================= NORMAL LOGIN ================= */
    @FXML
    private void onLogin(ActionEvent event) {

        lblStatus.setText("");

        String id = getTxtSubscriberId().getText();
        String name = txtSubscriberName.getText();

        if (id.isBlank() || name.isBlank()) {
            lblStatus.setText("Please fill all fields");
            return;
        }

        try {
            Integer.parseInt(id);
        } catch (NumberFormatException e) {
            lblStatus.setText("Subscriber ID must be a number");
            return;
        }

        ClientUI.chat.sendToServer(
                new SubscriberLoginRequest(id.trim(), name.trim())
        );
    }

    /* ================= QR LOGIN ================= */
    @FXML
    private void onLoginWithQR() {

        try {
            FileChooser chooser = new FileChooser();
            chooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("QR Images", "*.png")
            );

            File file = chooser.showOpenDialog(null);
            if (file == null) return;

            var image = ImageIO.read(file);
            var source = new BufferedImageLuminanceSource(image);
            var bitmap = new BinaryBitmap(new HybridBinarizer(source));

            Result result = new MultiFormatReader().decode(bitmap);

            String qrData = result.getText();   // SUBSCRIBER_ID:12

            if (!qrData.startsWith("SUBSCRIBER_ID:")) {
                lblStatus.setText("Invalid QR code");
                return;
            }

            String id = qrData.replace("SUBSCRIBER_ID:", "").trim();

            ClientUI.chat.sendToServer(
                    new Request("LOGIN_WITH_QR", id)
            );

        } catch (Exception e) {
            e.printStackTrace();
            lblStatus.setText("Failed to scan QR");
        }
    }

    /* ================= ERROR HANDLING ================= */
    public void showLoginError() {
        lblStatus.setText("Wrong Subscriber ID or Name");
    }

    public void showCustomError(String msg) {
        lblStatus.setText(msg);
    }
    public void showLoginSuccess(Subscriber subscriber, ActionEvent event) {
        try {

            String fxml = navigation.Navigation.getRoleSelectionScreen()
                    .equals("RoleSelectionTerminal.fxml")
                    ? "/gui/SubscriberMainTerminal.fxml"
                    : "/gui/SubscriberMainApp.fxml";

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            if (fxml.contains("App")) {
                SubscriberMainControllerApp ctrl = loader.getController();
                ctrl.setSubscriber(subscriber);
            } else {
                SubscriberMainController ctrl = loader.getController();
                ctrl.setSubscriber(subscriber);
            }

            Stage stage = new Stage();
            stage.setTitle("Subscriber Dashboard");
            stage.setScene(new Scene(root));
            stage.show();

            ((Stage) ((Node) event.getSource()).getScene().getWindow()).close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /* ================= BACK ================= */
    @FXML
    private void onBack(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/Interface.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage currentStage =
                    (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

	public TextField getTxtSubscriberId() {
		return txtSubscriberId;
	}

	public void setTxtSubscriberId(TextField txtSubscriberId) {
		this.txtSubscriberId = txtSubscriberId;
	}
}
