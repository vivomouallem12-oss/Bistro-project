package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import logic.Subscriber;

public class SubscriberMainControllerApp implements SubscriberChildScreen {

    @FXML
    private Label lblWelcome;

    private Subscriber subscriber;

    /* ================== INIT ================== */

    @Override
    public void setClient(client.ClientController client) {
        // Not needed for App
    }

    @Override
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;

        if (subscriber == null) {
            lblWelcome.setText("Welcome");
            return;
        }

        lblWelcome.setText(
                "Welcome, " +
                        subscriber.getUsername() +
                        " (ID: " +
                        subscriber.getSubscriberId() +
                        ")"
        );
    }

    /* ================== BUTTONS ================== */

    @FXML
    private void onMakeReservation(ActionEvent event) {
        openScreenWithSubscriber(
                "/gui/SubscriberReservationApp.fxml",
                "Make a Reservation",
                event
        );
    }

    @FXML
    private void onJoinWaitingList(ActionEvent event) {
        openScreenWithSubscriber(
                "/gui/WaitingListApp.fxml",
                "Waiting List",
                event
        );
    }

    @FXML
    private void onPayBill() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/EntryPaymentCode.fxml"));
            Parent root = loader.load();

            EntryPaymentCodeController ctrl = loader.getController();
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("Enter Confirmation Code");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onMyAccount(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/AccountHistory.fxml"));
            Parent root = loader.load();

            AccountHistoryController ctrl = loader.getController();
            ctrl.setSubscriber(subscriber);

            // 🔙 Tell AccountHistory where to go back to
            ctrl.setPreviousFXML("/gui/SubscriberMainApp.fxml");

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("My Account");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Failed to open Account History.");
        }
    }



    @FXML
    private void onLogout(ActionEvent event) {
        openScreenNoSubscriber(
                "/gui/SubscriberLogin.fxml",
                "Subscriber Login",
                event
        );
    }

    /* ================== NAV HELPERS ================== */

    private void openScreenWithSubscriber(String fxml, String title, ActionEvent event) {

        if (subscriber == null) {
            showError("Subscriber not loaded. Please login again.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();

            Object controller = loader.getController();

            // ✅ Pass subscriber
            if (controller instanceof SubscriberChildScreen) {
                ((SubscriberChildScreen) controller).setSubscriber(subscriber);
            }

            // ✅ If EntryPaymentCode – pass previous screen
            if (controller instanceof EntryPaymentCodeController) {
                ((EntryPaymentCodeController) controller)
                        .setSubscriber(subscriber);
            }

            // 🔁 REUSE SAME STAGE
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Failed to open screen: " + fxml);
        }
    }



    private void openScreenNoSubscriber(String fxml, String title, ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxml));

            Stage stage = new Stage();
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.show();

            closeCurrentStage(event);

        } catch (Exception e) {
            e.printStackTrace();
            showError("Failed to open screen: " + fxml);
        }
    }

    private void closeCurrentStage(ActionEvent event) {
        ((Stage) ((Node) event.getSource()).getScene().getWindow()).close();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.showAndWait();
    }
}
