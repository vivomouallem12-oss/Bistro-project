package gui;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logic.StaffLoginRequest;
import navigation.Navigation;

public class RepresentativeLoginController {

    private static RepresentativeLoginController active;

    public RepresentativeLoginController() {
        active = this;
    }

    public static RepresentativeLoginController getActive() {
        return active;
    }

    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private Label lblStatus;
    @FXML private Button backBtn, exitBtn;

    /* ================= LOGIN ================= */

    @FXML
    private void onLogin(ActionEvent event) {

        lblStatus.setText("");

        if (txtUsername.getText().isBlank() || txtPassword.getText().isBlank()) {
            lblStatus.setText("Please fill all fields");
            return;
        }

        ClientUI.chat.sendToServer(
            new StaffLoginRequest(
                txtUsername.getText().trim(),
                txtPassword.getText().trim()
            )
        );
    }

    /* ================= LOGIN SUCCESS (CALLED FROM ChatClient) ================= */

    public void showLoginSuccess() {
        try {
            Navigation.setRole(Navigation.Role.AGENT);

            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/RepresentativeHomepage.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

            Stage.getWindows().forEach(w -> {
                if (w instanceof Stage s && s != stage) {
                    s.close();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /* ================= LOGIN FAIL ================= */

    public void showLoginError() {
        lblStatus.setText("Wrong username or password");
    }

    /* ================= EXIT ================= */

    @FXML
    private void exit() {
        System.exit(0);
    }

    /* ================= BACK ================= */

    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getRoleSelectionScreen();

            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/" + target));

            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) ((Button) event.getSource())
                    .getScene().getWindow();

            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
