package gui;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logic.Request;
import logic.Subscriber;

public class WaitingListAppController implements SubscriberChildScreen {

    @FXML private TextField txtConfirmationCode;
    @FXML private Button btnLeaveWaitingList;
    @FXML private Button exitBtn, backBtn;

    private Subscriber subscriber;

    /* ================= REQUIRED ================= */

    @Override
    public void setClient(client.ClientController client) {
        // Not needed for App
    }

    @Override
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
    }

    /* ================= LEAVE WAITING LIST ================= */

    @FXML
    private void onLeaveWaitingList() {

        if (subscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        int code;
        try {
            code = Integer.parseInt(txtConfirmationCode.getText().trim());
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("LEAVE_WAITING_LIST", code)
        );
    }

    /* ================= BACK ================= */

    @FXML
    private void back(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberMainApp.fxml"));
            Parent root = loader.load();

            SubscriberMainControllerApp ctrl = loader.getController();
            ctrl.setSubscriber(subscriber);   // ✅ PASS SUBSCRIBER

            Stage stage = (Stage) ((Button) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void exit() {
        System.exit(0);
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Waiting List Error");
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
