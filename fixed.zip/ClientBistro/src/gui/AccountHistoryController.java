package gui;

import client.ClientController;
import client.ClientUI;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import logic.*;

import java.util.List;

public class AccountHistoryController implements SubscriberChildScreen {

    /* ================= TABLES ================= */

    @FXML private TableView<Order> reservationsTable;
    @FXML private TableView<Order> visitsTable;

    /* ===== RESERVATIONS COLUMNS ===== */
    @FXML private TableColumn<Order, Integer> colResId;
    @FXML private TableColumn<Order, String> colResDate;
    @FXML private TableColumn<Order, Integer> colGuests;
    @FXML private TableColumn<Order, String> colResStatus;

    /* ===== VISITS COLUMNS ===== */
    @FXML private TableColumn<Order, String> colVisitDate;
    @FXML private TableColumn<Order, Integer> colVisitPeople;
    @FXML private TableColumn<Order, String> colVisitStatus;

    @FXML private Button btnBack;

    private ClientController client;
    private Subscriber subscriber;

    // 🔙 Dynamic back target
    private String previousFXML;

    private static AccountHistoryController ACTIVE;

    /* ================= INIT ================= */

    @FXML
    public void initialize() {
        ACTIVE = this;

        /* ---------- RESERVATIONS ---------- */
        colResId.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getOrder_number()).asObject());

        colResDate.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_date()));

        colGuests.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getNumber_of_guests()).asObject());

        colResStatus.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_status()));

        /* ---------- VISITS ---------- */
        colVisitDate.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_date()));

        colVisitPeople.setCellValueFactory(d ->
                new SimpleIntegerProperty(d.getValue().getNumber_of_guests()).asObject());

        colVisitStatus.setCellValueFactory(d ->
                new SimpleStringProperty(d.getValue().getOrder_status()));

        btnBack.setOnAction(e -> goBack());
    }

    public static AccountHistoryController getActive() {
        return ACTIVE;
    }

    /* ================= CONTEXT ================= */

    @Override
    public void setClient(ClientController client) {
        this.client = client;
        System.out.println("ACCOUNT HISTORY → Client loaded");
    }


    @Override
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;

        System.out.println("ACCOUNT HISTORY → Subscriber ID: " + subscriber.getSubscriberId());

        // ✅ Always send requests (works for App + Terminal)
        ClientUI.chat.sendToServer(
            new Request("ACCOUNT_RESERVATIONS", subscriber.getSubscriberId())
        );

        ClientUI.chat.sendToServer(
            new Request("ACCOUNT_VISITS", subscriber.getSubscriberId())
        );
    }



    // 🔙 Set where Back should go
    public void setPreviousFXML(String fxml) {
        this.previousFXML = fxml;
    }

    /* ================= SERVER CALLBACKS ================= */

    public void handleReservationHistory(List<Order> reservations) {
        Platform.runLater(() -> {
            System.out.println("RESERVATIONS RECEIVED: " + reservations.size());
            reservationsTable.getItems().clear();
            reservationsTable.setItems(FXCollections.observableArrayList(reservations));
        });
    }

    public void handleVisitHistory(List<Order> visits) {
        Platform.runLater(() -> {
            System.out.println("VISITS RECEIVED: " + visits.size());
            visitsTable.getItems().clear();
            visitsTable.setItems(FXCollections.observableArrayList(visits));
        });
    }


    /* ================= NAVIGATION ================= */

    private void goBack() {
        try {
            if (previousFXML == null) {
                showError("No previous screen.");
                return;
            }

            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource(previousFXML));

            Parent root = loader.load();

            Object controller = loader.getController();

            if (controller instanceof SubscriberChildScreen) {
                ((SubscriberChildScreen) controller).setSubscriber(subscriber);
            }

            Stage stage = (Stage) btnBack.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            showError("Failed to go back.");
        }
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.showAndWait();
    }
}
