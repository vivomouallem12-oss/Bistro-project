package logic;

import java.io.Serializable;

public enum RequestType implements Serializable {

    // reservation flow
    AVAILABLE,
    SUGGESTED_TIMES,
    RESERVATION_CREATED,
    INVALID_INPUT,

    // code lookup
    CODE_FOUND,
    CODE_NOT_FOUND,
    CODES_SENT,
    NO_CODES_FOUND,

    // cancel/payment
    CANCEL_SUCCESS,
    CANCEL_FAILED,
    PAYMENT_SUCCESS,
    PAYMENT_FAILED,

    // terminal
    CHECKIN_SUCCESS,
    NO_AVAILABLE_TABLE,
    CHECKIN_NOT_ALLOWED,

    // history
    ACCOUNT_HISTORY,

    // generic
    SERVER_ERROR
}
