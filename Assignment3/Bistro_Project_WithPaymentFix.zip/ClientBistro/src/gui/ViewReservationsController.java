package gui;

import javafx.fxml.FXML;
import javafx.scene.control.TableView;

public class ViewReservationsController {

    @FXML
    private TableView<?> reservationsTable;

}
