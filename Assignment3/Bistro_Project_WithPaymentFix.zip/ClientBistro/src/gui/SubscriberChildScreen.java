package gui;

import client.ClientController;
import logic.Subscriber;

public interface SubscriberChildScreen {

    void setClient(ClientController client);

    void setSubscriber(Subscriber subscriber);
}
