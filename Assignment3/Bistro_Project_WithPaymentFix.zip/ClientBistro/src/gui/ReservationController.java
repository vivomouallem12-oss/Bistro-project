package gui;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import logic.Customer;
import logic.Order;
import logic.OrderCustomer;
import logic.Request;
import logic.Tables;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Random;
import client.ClientController;

public class ReservationController {
	
	 private ClientController client;
	 
	 public Order pendingOrder;
	 public Customer pendingCustomer;
	 public int codeForCancel=0;

    @FXML
    private Label guestCountLabel, codeStatusLabel, orderStatusLabel, lostCode;

    @FXML 
    private VBox orderDetailsBox;
    
    @FXML
    private HBox suggestedTimesBox;
    
    @FXML
    private Button minusGuestBtn, plusGuestBtn, orderBtn, subscriberBtn, checkReservationBtn, refreshBtn, exitBtn;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<String> timeSelect;

    @FXML
    private TextField nameField, phoneField, emailField, confirmationCodeField;

    private int guests = 2;
    
    private static ReservationController instance;
    
    
    
    public void setClient(ClientController client) {
        this.client = client;
    }
    
    public ReservationController() {
    	instance = this;
    }
    
    public static ReservationController getInstance() {
    	return instance;
    }
    
    @FXML
    public void initialize() {
        datePicker.setValue(LocalDate.now());
        timeSelect.setValue("17:00");
        
    }



    @FXML
    private void incGuests() {
        if (guests < 10) guests++;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void handleOrder() {
    	Random r = new Random();
    	int confirmation = r.nextInt((999999 - 100000)+1)+100000;
        LocalDate date = datePicker.getValue();
        String time = timeSelect.getValue();
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();
        
        if (date==null || time==null || name==null) {
        	orderFail("Please fill the details above.",null);
        	return;
        }

        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();
        LocalTime selectedTime = LocalTime.parse(time);
        LocalDateTime selectedDateTime = LocalDateTime.of(date, selectedTime);

        if (date.isBefore(today)) {
            orderFail("Selected date has passed.",null);
            return;
        }
        if (date.isAfter(today.plusDays(30))) {
            orderFail("Reservations can only be made up to 30 days in advance.",null);
            return;
        }
        if (selectedDateTime.isBefore(LocalDateTime.now().plusHours(1))) {
            orderFail("Reservations must be made at least 1 hour in advance.",null);
            return;
        }
        if (email == null ||!(email.endsWith("@gmail.com") || email.endsWith("@outlook.com"))) {
        	orderFail("Please enter a valid email.",null);
        	return;
        }
        if (phone.length() != 10 || !phone.matches("\\d+") || !(phone.startsWith("050") || phone.startsWith("052") || phone.startsWith("053") || phone.startsWith("054") || phone.startsWith("055") || phone.startsWith("058"))) {
        	orderFail("Please enter a valid phone number.",null);
        	return;
        }

        
        Customer customer = new Customer(name, email, phone);
        Order order = new Order(0,date.toString(),time,guests,confirmation,0,phone,email,LocalDate.now().toString(),0,"BOOKED",LocalDateTime.now().toString());
        
        Request tableRequest = new Request("FREE_TABLES",order);
        client.sendToServer(tableRequest);
        
        pendingOrder = order;
        pendingCustomer = customer;
    }
    
    public void handleFreeTables(List<Tables> freeTables) {
    		pendingOrder.setTable_num(freeTables.get(0).getTable_num());
    		Request customerRequest = new Request("INSERT_NEW_CUSTOMER",pendingCustomer);
    		Request orderRequest = new Request("INSERT_NEW_ORDER",pendingOrder);
    		client.sendToServer(customerRequest);
    		client.sendToServer(orderRequest);
    		orderStatusLabel.setText("Order successful.\nYou should recieve a confirmation code on your email!");
    		orderStatusLabel.setStyle("-fx-text-fill: green;");
            suggestedTimesBox.getChildren().clear();
            suggestedTimesBox.setVisible(false);
            suggestedTimesBox.setManaged(false);
    		
    	
    }
 
    public void orderFail(String msg,List<LocalTime> suggestions) {
    	if (suggestions==null || suggestions.isEmpty()) {
    		orderStatusLabel.setText("Unfortunately we didnt find a table for you today.");
            orderStatusLabel.setStyle("-fx-text-fill: red;");
    	}
    	else {
    		suggestedTimesBox.getChildren().clear();
    		suggestedTimesBox.setVisible(true);
    		suggestedTimesBox.setSpacing(10);
    		suggestedTimesBox.setPadding(new Insets(10));
    		suggestedTimesBox.setStyle("-fx-background-color: #f9f9f9; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 5);");
            orderStatusLabel.setText(msg);
            orderStatusLabel.setStyle("-fx-text-fill: red;");
            for (LocalTime t : suggestions) {
            	Button timeBtn = new Button(t.toString());
                timeBtn.setStyle("-fx-background-color: #1F51FF; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 5; -fx-padding: 6 12 6 12;");
                timeBtn.setOnAction(e -> {
                	 timeSelect.setValue(timeBtn.getText());
                });
            	suggestedTimesBox.getChildren().add(timeBtn);
            }
            
    	}

    }

    @FXML
    private void goToSubscriberLogin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void checkCode() {
    	try {
    	int conCode = Integer.parseInt(confirmationCodeField.getText());
    	Request r = new Request("CONFIRMATION_CODE",conCode);
    	client.sendToServer(r);
    	} catch(Exception e) {
    		e.printStackTrace();
    		codeStatus("Invalid input.","red");
    	}
    }
    
    public void codeSuccess(OrderCustomer oc) {
        Order order = oc.getOrder();
        Customer customer = oc.getCustomer();

        lostCode.setText("");
        codeStatusLabel.setText("");

        // Clear previous details
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setVisible(true);
        orderDetailsBox.setSpacing(10);
        orderDetailsBox.setPadding(new Insets(10));
        orderDetailsBox.setStyle("-fx-background-color: #f9f9f9; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 5);");

        // Create styled labels
        Label headerLabel = new Label("Welcome " + customer.getCustomer_name() + "!\nHere are your order details:");
        headerLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333333;");

        Label emailLabel = new Label("Email: " + customer.getCustomer_email());
        emailLabel.setStyle("-fx-text-fill: #555555;");

        Label phoneLabel = new Label("Phone: " + customer.getCustomer_phone());
        phoneLabel.setStyle("-fx-text-fill: #555555;");

        Label numLabel = new Label("Order Number: " + order.getOrder_number());
        numLabel.setStyle("-fx-text-fill: #555555;");

        Label guestsLabel = new Label("Guests: " + order.getNumber_of_guests());
        guestsLabel.setStyle("-fx-text-fill: #555555;");

        Label tableLabel = new Label("Table Number: " + order.getTable_num());
        tableLabel.setStyle("-fx-text-fill: #555555;");

        Label dateLabel = new Label("Date: " + order.getOrder_date());
        dateLabel.setStyle("-fx-text-fill: #555555;");

        Label timeLabel = new Label("Time: " + order.getOrder_time());
        timeLabel.setStyle("-fx-text-fill: #555555;");

        Label placedLabel = new Label("Order Placed On: " + order.getDate_of_placing_order());
        placedLabel.setStyle("-fx-text-fill: #999999; -fx-font-size: 12px;");

        Button cancelBtn = new Button("Cancel Order");
        cancelBtn.setStyle("-fx-background-color: #FF5252; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 5; -fx-padding: 6 12 6 12;");
        cancelBtn.setOnAction(e -> cancelOrder());
        
        Button payBtn = new Button("Pay Bill");
        payBtn.setStyle("-fx-background-color: #1F51FF; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 5; -fx-padding: 6 12 6 12;");
        payBtn.setOnAction(e -> payBill());
        
        codeForCancel = order.getConfirmation_code();

        if (!order.getOrder_status().equals("SEATED")) payBtn.setVisible(false);
        orderDetailsBox.getChildren().addAll(headerLabel, emailLabel, phoneLabel, numLabel, guestsLabel, tableLabel,dateLabel, timeLabel, placedLabel, cancelBtn, payBtn);


    }

    
    public void codeStatus(String msg,String color) {
    	orderDetailsBox.getChildren().clear();
    	orderDetailsBox.setVisible(false);
    	lostCode.setText("Lost code?");
        codeStatusLabel.setText(msg);
        codeStatusLabel.setStyle("-fx-text-fill: "+color+";");
    }
    
    public void cancelOrder() {
    	if (codeForCancel!=0) {
        	Request r = new Request("CANCEL_ORDER",codeForCancel);
        	client.sendToServer(r);
    	}
    }
    
    public void payBill() {
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setVisible(false);
        orderDetailsBox.setManaged(false);
        codeStatus("Thank you for visting!","green");
        client.sendToServer(new Request("PAY_BILL",codeForCancel));
    	
    }
    @FXML
    public void lostCode(MouseEvent event) {
        lostCode.setDisable(true);

        codeStatusLabel.setText("");
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setVisible(true);
        orderDetailsBox.setManaged(true);
        orderDetailsBox.setSpacing(10);
        orderDetailsBox.setPadding(new Insets(10));
        orderDetailsBox.setStyle( "-fx-background-color: #f9f9f9; " + "-fx-background-radius: 10; " + "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 5);");

        Label emailLabel = new Label("Please enter your email:");

        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");

        Button sendBtn = new Button("Send Code");
        sendBtn.setStyle("-fx-background-color: #1F51FF; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 5; -fx-padding: 6 12 6 12;");


        sendBtn.setOnAction(e -> {
            String email = emailField.getText().trim();
            if (email.isEmpty() || !(email.endsWith("@gmail.com") || email.endsWith("@outlook.com"))) {
                codeStatus("Please enter a valid email", "red");
                return;
            }
        	client.sendToServer(new Request("SEND_CODE",email));
        	codeStatus("A code was sent to your email","green"); 
        });

        orderDetailsBox.getChildren().addAll(emailLabel, emailField, sendBtn);
        lostCode.setDisable(false);
    }
    
    @FXML
    private void refresh() {
    	nameField.clear();
        phoneField.clear();
        emailField.clear();
        confirmationCodeField.clear();
        timeSelect.setValue("17:00");
        datePicker.setValue(LocalDate.now());
        guestCountLabel.setText("2");
        
        
        orderStatusLabel.setText("");
        codeStatusLabel.setText("");
        lostCode.setText("Lost code?");
        lostCode.setDisable(false);
        
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setVisible(false);
        orderDetailsBox.setManaged(false);
        
        suggestedTimesBox.getChildren().clear();
        suggestedTimesBox.setVisible(false);
        suggestedTimesBox.setManaged(false);
    }
    
    @FXML
    private void exit() {
    	System.exit(0);
    }
    
    @FXML
    private void back(ActionEvent event) {
    	   try {
               FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/RoleSelection.fxml"));
               Scene scene = new Scene(loader.load());
               Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
               stage.setScene(scene);
               stage.show();
           } catch (IOException e) {
               e.printStackTrace();
           }
    }

}
