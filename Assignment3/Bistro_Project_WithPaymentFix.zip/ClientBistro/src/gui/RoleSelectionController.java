package gui;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

/**
 * RoleSelectionController
 *
 * RESPONSIBILITY:
 * - Route users based on role
 * - Guest  -> Guest Reservation ONLY
 * - Subscriber -> Subscriber Login (never Guest reservation)
 * - Agent / Manager -> Their own screens
 */
public class RoleSelectionController {

    @FXML
    private AnchorPane anchorPane;

    @FXML private StackPane guestCard;
    @FXML private StackPane subscriberCard;
    @FXML private StackPane agentCard;
    @FXML private StackPane managerCard;

    @FXML
    public void initialize() {
        applyHoverEffect(guestCard);
        applyHoverEffect(subscriberCard);
        applyHoverEffect(agentCard);
        applyHoverEffect(managerCard);
    }

    // ==================================================
    //                    ROLE ROUTING
    // ==================================================

    /**
     * GUEST FLOW
     * RoleSelection -> Reservation.fxml (Guest only)
     */
    @FXML
    private void onGuestClicked() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("Reservation.fxml"));
            Parent root = loader.load();

            ReservationController controller = loader.getController();

            // Inject client (REQUIRED)
            controller.setClient(ClientUI.chat);

            // Explicitly mark as Guest
           // controller.setRole("Guest", true);

            anchorPane.getScene().setRoot(root);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * SUBSCRIBER FLOW
     * RoleSelection -> SubscriberLogin.fxml
     *
     * IMPORTANT:
     * Subscriber must NEVER enter Reservation.fxml directly.
     */
    @FXML
    private void onSubscriberClicked() {
        loadScreen("SubscriberLogin.fxml");
    }

    /**
     * AGENT FLOW
     */
    @FXML
    private void onAgentClicked() {
        loadScreen("AgentView.fxml");
    }

    /**
     * MANAGER FLOW
     */
    @FXML
    private void onManagerClicked() {
        loadScreen("TableManagement.fxml");
    }

    // ==================================================
    //                    HELPERS
    // ==================================================

    /**
     * Generic screen loader (NO client injection here)
     */
    private void loadScreen(String fxml) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Card hover animation
     */
    private void applyHoverEffect(StackPane card) {
        card.setOnMouseEntered(e -> {
            card.setScaleX(1.05);
            card.setScaleY(1.05);
        });

        card.setOnMouseExited(e -> {
            card.setScaleX(1.0);
            card.setScaleY(1.0);
        });
    }
}
