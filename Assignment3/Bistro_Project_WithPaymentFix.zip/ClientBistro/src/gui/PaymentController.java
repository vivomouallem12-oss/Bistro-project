package gui;

import client.ChatClient;
import client.ClientUI;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import logic.Request;
import logic.Subscriber;

public class PaymentController {

    @FXML private Label lblName;
    @FXML private Label lblOrder;
    @FXML private Label lblOriginal;
    @FXML private Label lblDiscount;
    @FXML private Label lblFinal;

    private int confirmationCode;
    private Subscriber subscriber;

    /* ================= INIT ================= */

    @FXML
    public void initialize() {
        // register controller in ChatClient
        ChatClient.setActivePaymentController(this);
    }

    /* ================= DATA ================= */

    public void setData(Subscriber sub, int confirmationCode, double price) {
        this.subscriber = sub;
        this.confirmationCode = confirmationCode;

        double discount = price * 0.10;
        double finalPrice = price - discount;

        if (sub != null) {
            lblName.setText("Subscriber: " + sub.getUsername());
        } else {
            lblName.setText("Subscriber");
        }

        lblOrder.setText("Confirmation Code: " + confirmationCode);
        lblOriginal.setText("Original Price: ₪" + price);
        lblDiscount.setText("Discount (10%): -₪" + discount);
        lblFinal.setText("Total to Pay: ₪" + finalPrice);
    }


    /* ================= PAY ================= */

    @FXML
    private void onPay() {

        // ✅ ONLY finalize payment
        ClientUI.chat.sendToServer(
                new Request("PAY_BILL", confirmationCode)
        );
    }

    /* ================= SERVER CALLBACKS ================= */

    public void showPaymentSuccess() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Payment Successful");
        alert.setHeaderText("Thank you for your payment Checkout sended to your email✅");
        alert.setContentText(
                "Payment completed successfully.\nEnjoy your meal!"
        );
        alert.showAndWait();
        closeWindow();
    }

    public void showPaymentFailed() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Payment Failed");
        alert.setHeaderText(null);
        alert.setContentText(
                "Payment could not be completed.\nPlease contact staff."
        );
        alert.showAndWait();
    }

    /* ================= BACK / CLOSE ================= */

    @FXML
    private void onBack() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) lblFinal.getScene().getWindow();
        stage.close();
    }
}
