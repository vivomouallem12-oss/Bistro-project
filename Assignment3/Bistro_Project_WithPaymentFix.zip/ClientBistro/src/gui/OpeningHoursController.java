package gui;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class OpeningHoursController {

    @FXML
    private ComboBox<String> dayBox;

    @FXML
    private TextField openField;

    @FXML
    private TextField closeField;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        dayBox.getItems().addAll(
                "Sunday",
                "Monday",
                "Tuesday",
                "Wednesday",
                "Thursday",
                "Friday",
                "Saturday",
                "Holiday / Special Day"
        );
    }

    @FXML
    private void saveHours() {
        String day = dayBox.getValue();
        String open = openField.getText();
        String close = closeField.getText();

        if (day == null || open.isEmpty() || close.isEmpty()) {
            statusLabel.setText("Please fill all fields");
            return;
        }

        statusLabel.setText("Opening hours updated (UI only)");
    }
}
