package gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class RoleSelectionController {
	@FXML
	private void onSubscriber() throws Exception {
	    FXMLLoader loader =
	            new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
	    Parent root = loader.load();

	    Stage stage = new Stage();
	    stage.setTitle("Subscriber Login");
	    stage.setScene(new Scene(root));
	    stage.show();
	}


    @FXML
    private Label titleLabel;

    @FXML
    private Button btnCasual;

    @FXML
    private Button btnSubscriber;

    @FXML
    private Button btnRepresentative;

    @FXML
    private Button btnManager;

    @FXML
    public void initialize() {

        // ===== כותרת =====
        titleLabel.setStyle(
                "-fx-font-size: 32px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: #2c2c2c;"
        );

        // ===== סגנון כללי לכפתורים =====
        String baseStyle =
                "-fx-font-size: 15px;" +
                "-fx-font-weight: bold;" +
                "-fx-background-radius: 14;" +
                "-fx-border-radius: 14;" +
                "-fx-border-width: 2;" +
                "-fx-border-color: black;" +
                "-fx-min-width: 260px;" +
                "-fx-min-height: 48px;";

        // ===== ירוק =====
        String greenStyle =
                baseStyle +
                "-fx-background-color: #1abc9c;" +
                "-fx-text-fill: white;";

        // ===== אפור =====
        String grayStyle =
                baseStyle +
                "-fx-background-color: #e0e0e0;" +
                "-fx-text-fill: #2c2c2c;";

        // סדר: ירוק, אפור, ירוק, אפור
        btnCasual.setStyle(greenStyle);
        btnSubscriber.setStyle(grayStyle);
        btnRepresentative.setStyle(greenStyle);
        btnManager.setStyle(grayStyle);
        
    }
}
