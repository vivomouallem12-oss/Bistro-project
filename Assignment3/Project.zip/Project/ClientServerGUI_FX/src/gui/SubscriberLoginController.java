package gui;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SubscriberLoginController {

    @FXML
    private TextField subscriberIdField;

    @FXML
    private Label errorLabel;

    @FXML
    private void onLogin() {
        String id = subscriberIdField.getText();

        if (id == null || id.isEmpty()) {
            errorLabel.setText("Subscriber ID is required");
            return;
        }

        // שליחה לשרת (כרגע רק הדפסה)
        System.out.println("Trying to login subscriber: " + id);

        // כאן בהמשך:
        // ClientUI.chat.accept("loginSubscriber:" + id);
    }

    @FXML
    private void onBack() {
        Stage stage = (Stage) subscriberIdField.getScene().getWindow();
        stage.close();
    }
}
