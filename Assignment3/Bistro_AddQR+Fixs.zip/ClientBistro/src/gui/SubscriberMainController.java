package gui;

import client.ClientController;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import logic.Subscriber;

public class SubscriberMainController implements SubscriberChildScreen{

    @FXML
    private Label lblWelcome;

    private ClientController client;

    // ✅ THE LOGGED-IN SUBSCRIBER
    private Subscriber subscriber;

    /* ================== INIT ================== */
    @Override
    public void setClient(ClientController client) {
        this.client = client;
    }

    @Override
    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;

        lblWelcome.setText(
                "Welcome, " +
                subscriber.getUsername() +
                " (ID: " +
                subscriber.getSubscriberId() +
                ")"
        );
    }

    /* ================== BUTTONS ================== */

    @FXML
    private void onMakeReservation(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberReservation.fxml"));
            Parent root = loader.load();

            SubscriberReservationController ctrl =
                    loader.getController();

            // ✅ PASS SUBSCRIBER
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("Make a Reservation");
            stage.setScene(new Scene(root));
            stage.show();

            closeCurrentStage(event);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================== WAITING LIST ================== */

    @FXML
    private void onJoinWaitingList(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/WaitingList.fxml"));
            Parent root = loader.load();

            WaitingListController ctrl = loader.getController();

            // ✅ PASS LOGGED-IN SUBSCRIBER
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("Waiting List");
            stage.setScene(new Scene(root));
            stage.show();

            closeCurrentStage(event);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================== PAY BILL ================== */

    @FXML
    private void onPayBill() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/EntryPaymentCode.fxml"));
            Parent root = loader.load();

            EntryPaymentCodeController ctrl = loader.getController();
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("Enter Confirmation Code");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================== ACCOUNT ================== */

    @FXML
    private void onMyAccount(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/AccountHistory.fxml"));
            Parent root = loader.load();

            AccountHistoryController ctrl =
                    loader.getController();

            ctrl.setClient(client);
            ctrl.setSubscriber(subscriber);

            Stage stage = new Stage();
            stage.setTitle("My Account History");
            stage.setScene(new Scene(root));
            stage.show();

            closeCurrentStage(event);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================== LOGOUT ================== */

    @FXML
    private void onLogout(ActionEvent event) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Subscriber Login");
            stage.setScene(new Scene(root));
            stage.show();

            // close current dashboard
            closeCurrentStage(event);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    




    /* ================== HELPERS ================== */

    private void closeCurrentStage(ActionEvent event) {
        ((Stage) ((Node) event.getSource())
                .getScene().getWindow()).close();
    }
}

