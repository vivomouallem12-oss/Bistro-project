package navigation;

public class Navigation {

    // ===== MODE (App / Terminal) =====
    public enum Mode {
        TERMINAL,
        APP
    }

    private static Mode currentMode;

    public static void setMode(Mode mode) {
        currentMode = mode;
    }

    public static String getRoleSelectionScreen() {
        if (currentMode == Mode.TERMINAL) {
            return "RoleSelectionTerminal.fxml";
        } else {
            return "RoleSelectionApp.fxml";
        }
    }

    // ===== ROLE (Manager / Agent) =====
    public enum Role {
        MANAGER,
        AGENT
    }

    private static Role currentRole;

    public static void setRole(Role role) {
        currentRole = role;
    }

    public static String getHomeByRole() {
        if (currentRole == Role.MANAGER) {
            return "ManagerHomePage.fxml";
        } else {
            return "RepresentativeHomepage.fxml";
        }
    }
}
