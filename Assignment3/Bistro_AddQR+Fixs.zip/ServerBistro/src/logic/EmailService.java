package logic;

import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.util.List;
import java.util.Properties;

public class EmailService {

    private static final String FROM_EMAIL = "bistro.customer.service@gmail.com";
    private static final String APP_PASSWORD = "mnxl uaeu hayf ztax";

    // =====================================================
    // COMMON SESSION
    // =====================================================
    private static Session createSession() {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        return Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
            }
        });
    }

    private static void sendEmail(String toEmail, String subject, String body) throws MessagingException {
        Session session = createSession();

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
        message.setSubject(subject);
        message.setText(body);

        Transport.send(message);
    }

    // =====================================================
    // 1) NEW RESERVATION CONFIRMATION
    // =====================================================
    public static void sendConfirmationEmail(String toEmail, int confirmationCode) {
        try {
            sendEmail(
                toEmail,
                "Reservation Confirmed",
                "Thank you for making a reservation with Bistro!\n\n" +
                "Your confirmation code is:\n" +
                confirmationCode + "\n\n" +
                "Please keep this code for check-in, payment, or cancellation.\n\n" +
                "We look forward to seeing you!"
            );
            System.out.println("[EMAIL] Reservation confirmation sent to " + toEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // =====================================================
    // 2) RESERVATION CANCELLATION
    // =====================================================
    public static void sendCancelEmail(String toEmail, int confirmationCode) {
        try {
            sendEmail(
                toEmail,
                "Reservation Cancelled",
                "Your reservation has been successfully cancelled.\n\n" +
                "Confirmation Code: " + confirmationCode + "\n\n" +
                "Thank you for choosing Bistro.\n" +
                "We hope to see you again soon!"
            );
            System.out.println("[EMAIL] Reservation cancel email sent to " + toEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // =====================================================
    // 3) WAITING LIST CANCELLATION
    // =====================================================
    public static void sendWaitingCancelEmail(String toEmail, int confirmationCode) {
        try {
            sendEmail(
                toEmail,
                "Waiting List Cancelled",
                "You have been removed from the waiting list.\n\n" +
                "Confirmation Code: " + confirmationCode + "\n\n" +
                "Thank you for choosing Bistro."
            );
            System.out.println("[EMAIL] Waiting list cancel email sent to " + toEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // =====================================================
    // 4) LOST CODES / TABLE READY / WAITING CALLED
    // =====================================================
    public static void LostCodeEmail(String toEmail, List<String> lines) {
        try {
            StringBuilder body = new StringBuilder();

            for (String line : lines) {
                body.append(line).append("\n");
            }

            sendEmail(
                toEmail,
                "Your Reservation Information",
                body.toString()
            );

            System.out.println("[EMAIL] Reservation info sent to " + toEmail);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // =====================================================
    // 5) REMINDER EMAIL (2 HOURS BEFORE)
    // =====================================================
    public static void sendReminderEmail(String toEmail) {
        try {
            sendEmail(
                toEmail,
                "Reservation Reminder",
                "Hello,\n\n" +
                "This is a reminder that you have a reservation in 2 hours.\n" +
                "We look forward to seeing you!\n\n" +
                "Bistro Restaurant"
            );

            System.out.println("[EMAIL] Reminder sent to " + toEmail);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    // =====================================================
    // 6) PAYMENT RECEIPT (WITH SUBSCRIBER DISCOUNT)
    // =====================================================
    public static void sendPaymentReceiptEmail(
            String toEmail,
            int confirmationCode,
            double price,
            int isSubscriber
    ) {
        try {

            double finalPrice = price;
            String discountLine = "";

            if (isSubscriber != 0) {
                finalPrice = price * 0.9; // 10% discount
                discountLine = "🎉 Subscriber Discount Applied (10%)\n\n";
            }

            sendEmail(
                toEmail,
                "Payment Receipt - Bistro",
                "Thank you for your payment!\n\n" +
                "Confirmation Code: " + confirmationCode + "\n" +
                "Total Paid: ₪" + String.format("%.2f", finalPrice) + "\n\n" +
                discountLine +
                "We hope to see you again soon!\n\n" +
                "Best regards,\n" +
                "Bistro Restaurant"
            );

            // Print final price in console log after discount
            System.out.println("[EMAIL] Payment receipt sent to " + toEmail +
                               " | Original Price: ₪" + String.format("%.2f", price) +
                               " | Final Price: ₪" + String.format("%.2f", finalPrice));

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

 }

