package gui;

import client.ClientUI;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import navigation.Navigation;

import java.util.List;

/**
 * Controller for viewing all reservations.
 * <p>
 * Displays reservations in a {@link TableView} with columns for date, time, number of guests, and status.
 * Handles navigation back to the home screen and exiting the application.
 * </p>
 */
public class ViewReservationsController {

    /** Reference to the active controller instance. */
    public static ViewReservationsController activeController;

    /** TableView displaying reservations. */
    @FXML
    private TableView<Order> reservationsTable;

    /** Column for reservation date. */
    @FXML
    private TableColumn<Order, String> dateCol;

    /** Column for reservation time. */
    @FXML
    private TableColumn<Order, String> timeCol;

    /** Column for number of guests in reservation. */
    @FXML
    private TableColumn<Order, Integer> guestsCol;

    /** Column for reservation status. */
    @FXML
    private TableColumn<Order, String> statusCol;

    /** Back button to navigate to home screen. */
    @FXML
    private Button backBtn;

    /** Exit button to close the application. */
    @FXML
    private Button exitBtn;

    /** Observable list storing reservations to display in TableView. */
    private final ObservableList<Order> reservationsList = FXCollections.observableArrayList();

    /**
     * Initializes the controller.
     * <p>
     * Sets up TableView columns and requests all reservations from the server.
     * </p>
     */
    @FXML
    public void initialize() {
        activeController = this;

        dateCol.setCellValueFactory(new PropertyValueFactory<>("order_date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("order_time"));
        guestsCol.setCellValueFactory(new PropertyValueFactory<>("number_of_guests"));
        statusCol.setCellValueFactory(new PropertyValueFactory<>("order_status"));

        reservationsTable.setItems(reservationsList);

        // Request all reservations from the server
        ClientUI.chat.sendToServer(new Request("GET_ALL_RESERVATIONS", null));
    }

    /**
     * Populates the TableView with a list of reservations.
     *
     * @param orders a {@link List} of {@link Order} objects to display
     */
    public void setReservations(List<Order> orders) {
        reservationsList.clear();
        reservationsList.addAll(orders);
    }

    /**
     * Exits the application.
     */
    @FXML
    private void exit() {
        System.exit(0);
    }

    /**
     * Navigates back to the home screen based on the user's role.
     *
     * @param event the {@link ActionEvent} triggered by the back button
     */
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getHomeByRole();

            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/" + target));
            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}