package logic;

import java.time.LocalTime;
import java.util.List;

public interface ReservationHandler {

    void handleFreeTables(int i);

    void orderFail(String message, List<LocalTime> suggestions);

    void codeSuccess(OrderCustomer order);

    void codeStatus(String message,String color);
    
    void updateTimes(String time);
}
