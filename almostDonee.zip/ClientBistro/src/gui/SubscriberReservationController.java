package gui;

import client.ClientUI;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import logic.Subscriber;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SubscriberReservationController {

    @FXML private Label lblWelcome, lblGuests, lblName, lblEmail, lblPhone;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox<String> timeBox;
    @FXML private TextField txtConfirmationCode;

    private int guests = 2;
    private Subscriber currentSubscriber;
    private Order pendingOrder;

    private static SubscriberReservationController ACTIVE;

    // Formatter for LocalTime -> HH:mm
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    /* ================= INIT ================= */
    @FXML
    public void initialize() {
        ACTIVE = this;

        lblGuests.setText(String.valueOf(guests));
        datePicker.setValue(LocalDate.now());

        timeBox.getItems().addAll(
                "17:00","17:30","18:00","18:30",
                "19:00","19:30","20:00","20:30","21:00","21:30"
        );
        timeBox.getSelectionModel().selectFirst();
    }

    public static SubscriberReservationController getActive() {
        return ACTIVE;
    }

    public void setSubscriber(Subscriber sub) {
        this.currentSubscriber = sub;

        lblWelcome.setText("Welcome back, " + sub.getUsername());
        lblName.setText(sub.getUsername());
        lblEmail.setText(sub.getEmail());
        lblPhone.setText(sub.getPhone());
    }

    /* ================= GUESTS ================= */
    @FXML
    private void incGuests() {
        if (guests < 10) guests++;
        lblGuests.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        lblGuests.setText(String.valueOf(guests));
    }

    /* ================= RESERVE ================= */
    @FXML
    private void onReserve() {

        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        Order order = new Order(
                0,
                datePicker.getValue().toString(),
                timeBox.getValue(),
                guests,
                0,
                currentSubscriber.getSubscriberId(),
                currentSubscriber.getPhone(),
                currentSubscriber.getEmail(),
                LocalDate.now().toString(),
                0,
                "BOOKED",
                null,
                false
        );

        pendingOrder = order;

        ClientUI.chat.sendToServer(
                new Request("CHECK_AVAILABILITY", order)
        );
    }

    /* ================= CANCEL RESERVATION ================= */
    @FXML
    private void onCancelReservation() {

        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        int code;
        try {
            code = Integer.parseInt(txtConfirmationCode.getText().trim());
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Cancel Reservation");
        confirm.setHeaderText("Are you sure?");
        confirm.setContentText(
                "This will cancel your reservation.\n" +
                "Confirmation Code: " + code
        );

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK)
            return;

        ClientUI.chat.sendToServer(
                new Request("CANCEL_ORDER", code)
        );
    }

    public void sendCreateReservation() {
        if (pendingOrder == null) {
            showError("No pending order found. Please click Reserve again.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("CREATE_RESERVATION", pendingOrder)
        );
    }

    /* ================= SUGGESTED TIMES FIX ================= */
    public void showSuggestedTimes(List<LocalTime> times) {
        Platform.runLater(() -> {
            if (times == null || times.isEmpty()) {
                showInfo("Sorry, no tables are available at your selected time.");
                return;
            }

            // Convert LocalTime -> HH:mm
            String timesStr = times.stream()
                                   .map(t -> t.format(timeFormatter))
                                   .collect(Collectors.joining(", "));

            // Show info alert
            showInfo("No tables available at your selected time.\nSuggested times:\n" + timesStr);
        });
    }

    /* ================= CHECK IN ================= */
    @FXML
    private void onCheckIn() {

        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        try {
            int code = Integer.parseInt(txtConfirmationCode.getText().trim());

            ClientUI.chat.sendToServer(
                    new Request("TERMINAL_CHECKIN", code)
            );

        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
        }
    }

    /* ================= LOST CODE ================= */
    @FXML
    private void onForgotConfirmationCode() {

        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("LOST_CONFIRMATION_CODE",
                        currentSubscriber.getSubscriberId())
        );
    }

    /* ================= SERVER CALLBACKS ================= */
    public void handleCheckInSuccess() {
        showInfo("Check-In successful ✅\nWelcome!");
        resetCheckInInput();
    }

    public void handleCheckInSuccess(int tableNum, int code) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Check-In Successful");
        alert.setHeaderText("Welcome! Your table is ready ✅");
        alert.setContentText(
                "Confirmation Code: " + code +
                "\nPlease go to Table #" + tableNum +
                ".\nEnjoy your meal!"
        );
        alert.showAndWait();

        resetCheckInInput();
    }

    public void handleCheckInWait() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("No Table Available Yet");
        alert.setHeaderText("Please wait ⏳");
        alert.setContentText(
                "All matching tables are currently occupied.\n" +
                "We will notify you as soon as a table is free."
        );
        alert.showAndWait();

        resetCheckInInput();
    }

    public void handleCheckInError(String msg) {
        showError(msg);
        resetCheckInInput();
    }

    /* ================= BACK ================= */
    @FXML
    private void onBack() {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));
            Parent root = loader.load();

            SubscriberMainController ctrl = loader.getController();
            ctrl.setClient(ClientUI.chat);
            ctrl.setSubscriber(currentSubscriber);

            Stage stage = (Stage) lblGuests.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onEditPhone() {
        TextInputDialog dialog = new TextInputDialog(lblPhone.getText());
        dialog.setTitle("Edit Phone");
        dialog.setHeaderText("Change your phone number");
        dialog.setContentText("New phone:");

        dialog.showAndWait().ifPresent(newPhone -> {
            if (!newPhone.matches("\\d{9,10}")) {
                showError("Invalid phone number.");
                return;
            }

            ClientUI.chat.sendToServer(
                new Request(
                    "UPDATE_SUBSCRIBER_PHONE",
                    Map.of(
                        "subscriberId", currentSubscriber.getSubscriberId(),
                        "phone", newPhone
                    )
                )
            );
        });
    }

    @FXML
    private void onEditEmail() {
        TextInputDialog dialog = new TextInputDialog(lblEmail.getText());
        dialog.setTitle("Edit Email");
        dialog.setHeaderText("Change your email");
        dialog.setContentText("New email:");

        dialog.showAndWait().ifPresent(newEmail -> {
            if (!newEmail.contains("@")) {
                showError("Invalid email.");
                return;
            }

            ClientUI.chat.sendToServer(
                new Request(
                    "UPDATE_SUBSCRIBER_EMAIL",
                    Map.of(
                        "subscriberId", currentSubscriber.getSubscriberId(),
                        "email", newEmail
                    )
                )
            );
        });
    }

    /* ================= HELPERS ================= */
    private void resetCheckInInput() {
        txtConfirmationCode.clear();
        txtConfirmationCode.requestFocus();
    }
    public void applyUpdatedEmail(String newEmail) {
        lblEmail.setText(newEmail);
        currentSubscriber.setEmail(newEmail);
    }

    public void applyUpdatedPhone(String newPhone) {
        lblPhone.setText(newPhone);
        currentSubscriber.setPhone(newPhone);
    }

    public void updateEmailLabel(String newEmail) {
        lblEmail.setText(newEmail);
    }

    public void updatePhoneLabel(String newPhone) {
        lblPhone.setText(newPhone);
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.showAndWait();
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.showAndWait();
    }

    public void codeStatus(String msg, String color) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.showAndWait();
    }

    @FXML
    private void refresh() {
    }

    @FXML
    private void exit() {
        System.exit(0);
    }

    @FXML
    private void back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/RoleSelectionTerminal.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
