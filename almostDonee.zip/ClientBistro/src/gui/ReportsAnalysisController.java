package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;
import client.ClientUI;
import logic.Request;


public class ReportsAnalysisController {

    public static ReportsAnalysisController activeController;

    @FXML
    private LineChart<String, Number> arrivalChart;

    @FXML
    private BarChart<String, Number> reservationChart;
    @FXML Button backBtn,exitBtn;
    
    @FXML
    public void initialize() {
        activeController = this;

        ClientUI.chat.sendToServer(
            new Request("GET_REPORTS_DATA", null)
        );
    }

    

    public void setReportsData(
            Map<String, Map<String, Integer>> data) {

        arrivalChart.getData().clear();
        reservationChart.getData().clear();

        // ===== Arrival / Delays =====
        XYChart.Series<String, Number> arrivalSeries =
                new XYChart.Series<>();
        arrivalSeries.setName("Average Delay");

        if (data.get("arrival") != null) {
            data.get("arrival").forEach((label, value) ->
                    arrivalSeries.getData().add(
                            new XYChart.Data<>(label, value))
            );
        }

        arrivalChart.getData().add(arrivalSeries);

        // ===== Reservations =====
        XYChart.Series<String, Number> reservationsSeries =
                new XYChart.Series<>();
        reservationsSeries.setName("Reservations");

        if (data.get("reservations") != null) {
            data.get("reservations").forEach((label, value) ->
                    reservationsSeries.getData().add(
                            new XYChart.Data<>(label, value))
            );
        }

        // ===== Waiting List =====
        XYChart.Series<String, Number> waitingSeries =
                new XYChart.Series<>();
        waitingSeries.setName("Waiting List");

        if (data.get("waiting") != null) {
            data.get("waiting").forEach((label, value) ->
                    waitingSeries.getData().add(
                            new XYChart.Data<>(label, value))
            );
        }

        reservationChart.getData().addAll(
                reservationsSeries,
                waitingSeries
        );
    }
    
    
    @FXML
    private void exit() {
    	System.exit(0);
    }
    
    @FXML
    private void back(ActionEvent event) {
    	   try {
               FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/Interface.fxml"));
               Scene scene = new Scene(loader.load());
               Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
               stage.setScene(scene);
               stage.show();
           } catch (IOException e) {
               e.printStackTrace();
           }
    }
    
}
