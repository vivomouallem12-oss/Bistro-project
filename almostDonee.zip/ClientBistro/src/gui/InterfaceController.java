package gui;

import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;

/**
 * RoleSelectionController
 *
 * RESPONSIBILITY:
 * - Route users based on role
 * - Guest  -> Guest Reservation ONLY
 * - Subscriber -> Subscriber Login (never Guest reservation)
 * - Agent / Manager -> Their own screens
 */
public class InterfaceController {

    @FXML
    private AnchorPane anchorPane;

    @FXML private StackPane terminalCard;
    @FXML private StackPane appCard;

    @FXML
    public void initialize() {
        applyHoverEffect(terminalCard);
        applyHoverEffect(appCard);
    }

    // ==================================================
    //                    ROLE ROUTING
    // ==================================================


    @FXML
    private void onTerminalClicked() {
        loadScreen("RoleSelectionTerminal.fxml");
    }
    @FXML
    private void onAppClicked() {
        loadScreen("RoleSelectionApp.fxml");
    }

    private void loadScreen(String fxml) {
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource(fxml));
            Parent root = loader.load();
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void applyHoverEffect(StackPane card) {
        card.setOnMouseEntered(e -> {
            card.setScaleX(1.05);
            card.setScaleY(1.05);
        });

        card.setOnMouseExited(e -> {
            card.setScaleX(1.0);
            card.setScaleY(1.0);
        });
    }
}
