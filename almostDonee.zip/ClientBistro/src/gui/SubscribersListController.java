package gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import logic.Subscriber;
import navigation.Navigation;
import client.ClientUI;
import logic.Request;

import java.io.IOException;
import java.util.List;

public class SubscribersListController {

    public static SubscribersListController activeController;

    public SubscribersListController() {
        activeController = this;
    }

    @FXML private TableView<Subscriber> table;
    @FXML private TableColumn<Subscriber, Integer> colId;
    @FXML private TableColumn<Subscriber, String> colName;
    @FXML private TableColumn<Subscriber, String> colEmail;
    @FXML private TableColumn<Subscriber, String> colPhone;
    @FXML private Button exitBtn,backBtn;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("subscriberId"));
        colName.setCellValueFactory(new PropertyValueFactory<>("username"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));

        // 🔥 זה החיבור ל-DB
        ClientUI.chat.sendToServer(
            new Request("GET_ALL_SUBSCRIBERS", null)
        );
    }


    public void setSubscribers(List<Subscriber> list) {
        table.getItems().setAll(list);
    }

    
    @FXML
    private void exit() {
    	System.exit(0);
    }
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getHomeByRole();

            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/" + target));

            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) ((Button) event.getSource())
                    .getScene().getWindow();

            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
}
