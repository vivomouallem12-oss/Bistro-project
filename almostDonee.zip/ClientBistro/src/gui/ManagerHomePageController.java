package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import navigation.Navigation;

public class ManagerHomePageController {

    @FXML private Button exitBtn, backBtn;

    /* ================= SIMPLE NAVIGATION ================= */
    private void go(ActionEvent event, String targetFxml) {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + targetFxml)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= BUTTONS ================= */

    @FXML
    private void onRegisterSubscriber(ActionEvent event) {
        go(event, "RegisterSubscriber.fxml");
    }

    @FXML
    void onSubscribers(ActionEvent event) {
        go(event, "SubscribersList.fxml");
    }

    @FXML
    void onCurrentCustomers(ActionEvent event) {
        go(event, "CurrentCustomers.fxml");
    }

    @FXML
    void onActiveReservations(ActionEvent event) {
        go(event, "ActiveReservations.fxml");
    }

    @FXML
    private void onManageTables(ActionEvent event) {
        go(event, "TableManagement.fxml");
    }

    @FXML
    private void onViewReservations(ActionEvent event) {
        go(event, "ViewReservation.fxml");
    }

    @FXML
    private void onOpeningHours(ActionEvent event) {
        go(event, "OpeningHours.fxml");
    }

    @FXML
    private void onWaitingList(ActionEvent event) {
        go(event, "ShowWaitingList.fxml");
    }

    @FXML
    private void onViewingManagementInformation(ActionEvent event) {
        go(event, "ManagementInfo.fxml");
    }

    @FXML
    private void onReportsAndAnalysis(ActionEvent event) {
        go(event, "ReportsAnalysis.fxml");
    }

    @FXML
    private void onSubscriberDashboard(ActionEvent event) {
        go(event, "SubscriberLogin.fxml");
    }

    @FXML
    private void onGuestDashboard(ActionEvent event) {
        go(event, "TerminalReservation.fxml");
    }

    /* ================= BACK ================= */
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getRoleSelectionScreen();
            System.out.println("BACK TO: " + target);

            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + target)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= EXIT ================= */
    @FXML
    private void exit() {
        System.exit(0);
    }
}
