package gui;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import client.ChatClient;
import client.ClientController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import logic.Order;

public class EditOrderFrameController {

    private ClientController client;
    private Order currentOrder;

    @FXML private TextField txtOrderNumber;
    @FXML private TextField txtOrderDate;
    @FXML private TextField txtGuests;
    @FXML private TextField txtConfirmationCode;
    @FXML private TextField txtSubscriberId;
    @FXML private TextField txtPlacedOn;

    public void setClient(ClientController client) {
        this.client = client;
    }

    public void loadOrder(Order o) {
        this.currentOrder = o;
        txtOrderNumber.setText(String.valueOf(o.getOrder_number()));
        txtOrderDate.setText(o.getOrder_date());
        txtGuests.setText(String.valueOf(o.getNumber_of_guests()));
        txtConfirmationCode.setText(String.valueOf(o.getConfirmation_code()));
        txtSubscriberId.setText(String.valueOf(o.getSubscriber_id()));
        txtPlacedOn.setText(o.getDate_of_placing_order());
    }
    
   
    @FXML
    public void saveOrder(ActionEvent event) throws Exception {
    	try {
    	Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?allowLoadLocalInfile=true&serverTimezone=Asia/Jerusalem&useSSL=false", "root", "Aa123456");
        System.out.println("SQL connection success");
        
        String sqlOrder = "UPDATE `order` SET order_number = ?, order_date = ?, number_of_guests = ?, confirmation_code = ?, subscriber_id = ?, date_of_placing_order = ? WHERE order_number = ?";
        PreparedStatement psOrder = conn.prepareStatement(sqlOrder);
        psOrder.setInt(1, Integer.parseInt(txtOrderNumber.getText()));
        psOrder.setString(2, txtOrderDate.getText());
        psOrder.setInt(3, Integer.parseInt(txtGuests.getText()));
        psOrder.setInt(4, Integer.parseInt(txtConfirmationCode.getText()));
        psOrder.setInt(5, Integer.parseInt(txtSubscriberId.getText()));
        psOrder.setString(6, txtPlacedOn.getText());
        psOrder.setInt(7, Integer.parseInt(txtOrderNumber.getText()));
        
        psOrder.executeUpdate();
        
        if (AllOrdersFrameController.ordersList.contains(currentOrder)) {
            int index = AllOrdersFrameController.ordersList.indexOf(currentOrder);
            AllOrdersFrameController.ordersList.set(index, currentOrder); // updates the ObservableList
        }
        
        FXMLLoader loader = new FXMLLoader();
		((Node)event.getSource()).getScene().getWindow().hide(); 
		Stage primaryStage = new Stage();
		Pane root = loader.load(getClass().getResource("/gui/AllOrders.fxml").openStream());
		AllOrdersFrameController afc = loader.getController();		
		Scene scene = new Scene(root);			
		primaryStage.setTitle("All orders");
		primaryStage.setScene(scene);		
		primaryStage.show();
		
    	} catch (SQLException ex) {
    		 System.out.println("SQLException: " + ex.getMessage());
	         System.out.println("SQLState: " + ex.getSQLState());
	         System.out.println("VendorError: " + ex.getErrorCode());
    	}
    	
    }
    
    public void returns(ActionEvent event) throws Exception {
		FXMLLoader loader = new FXMLLoader();
		((Node)event.getSource()).getScene().getWindow().hide();
		Stage primaryStage = new Stage();
		Pane root = loader.load(getClass().getResource("/gui/AllOrders.fxml").openStream());
		AllOrdersFrameController afc = loader.getController();		
		Scene scene = new Scene(root);			
		primaryStage.setTitle("All orders");
		primaryStage.setScene(scene);		
		primaryStage.show();
	}
}
