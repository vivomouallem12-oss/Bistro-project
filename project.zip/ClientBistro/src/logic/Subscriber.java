package logic;

import java.io.Serializable;

public class Subscriber implements Serializable{
	
	private int subscriber_id;
	private String subscriber_name;
	private String subscriber_email;
	private String subscriber_phone;
	
	public Subscriber(int subscriber_id, String subscriber_name,String subscriber_email,String subscriber_phone) {
		this.subscriber_id = subscriber_id;
		this.subscriber_name = subscriber_name;
		this.subscriber_email = subscriber_email;
		this.subscriber_phone = subscriber_phone;
	}

	public int getSubscriber_id() {
		return subscriber_id;
	}
	public void setSubscriber_id(int subscriber_id) {
		this.subscriber_id = subscriber_id;
	}

	public String getSubscriber_name() {
		return subscriber_name;
	}
	public void setSubscriber_name(String subscriber_name) {
		this.subscriber_name = subscriber_name;
	}

	public String getSubscriber_email() {
		return subscriber_email;
	}

	public void setSubscriber_email(String subscriber_email) {
		this.subscriber_email = subscriber_email;
	}

	public String getSubscriber_phone() {
		return subscriber_phone;
	}

	public void setSubscriber_phone(String subscriber_phone) {
		this.subscriber_phone = subscriber_phone;
	}

	@Override
	public String toString() {
		return "Subscriber [subscriber_id=" + subscriber_id + ", subscriber_name=" + subscriber_name + "]";
	}
	
	
	
	
	

}
