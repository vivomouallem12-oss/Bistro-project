package gui;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import logic.Customer;
import logic.Order;
import logic.OrderCustomer;
import logic.Request;
import logic.Tables;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Random;
import client.ClientController;

public class HomepageController {
	
	 private ClientController client;
	 
	 public Order pendingOrder;
	 public Customer pendingCustomer;
	 public int codeForCancel=0;

    @FXML
    private Label guestCountLabel, codeStatusLabel, orderStatusLabel, lostCode;

    @FXML 
    private VBox orderDetailsBox;
    @FXML
    private Button minusGuestBtn, plusGuestBtn, orderBtn, subscriberBtn, checkReservationBtn, refreshBtn, exitBtn;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<String> timeSelect;

    @FXML
    private TextField nameField, phoneField, emailField, confirmationCodeField;

    private int guests = 2;
    
    private static HomepageController instance;
    
    
    
    public void setClient(ClientController client) {
        this.client = client;
    }
    
    public HomepageController() {
    	instance = this;
    }
    
    public static HomepageController getInstance() {
    	return instance;
    }



    @FXML
    private void incGuests() {
        if (guests < 10) guests++;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void handleOrder() {
    	Random r = new Random();
    	int confirmation = r.nextInt((999999 - 100000)+1)+100000;
        LocalDate date = datePicker.getValue();
        String time = timeSelect.getValue();
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();
        
        if (date==null || time==null || name==null) {
        	orderFail("Please fill the details above.");
        	return;
        }

        LocalDate today = LocalDate.now();
        LocalTime now = LocalTime.now();
        LocalTime selectedTime = LocalTime.parse(time);
        LocalDateTime selectedDateTime = LocalDateTime.of(date, selectedTime);

        if (date.isBefore(today)) {
            orderFail("Selected date has passed.");
            return;
        }
        if (date.isAfter(today.plusDays(30))) {
            orderFail("Reservations can only be made up to 30 days in advance.");
            return;
        }
        if (selectedDateTime.isBefore(LocalDateTime.now().plusHours(1))) {
            orderFail("Reservations must be made at least 1 hour in advance.");
            return;
        }
        if (email == null ||!(email.endsWith("@gmail.com") || email.endsWith("@outlook.com"))) {
        	orderFail("Please enter a valid email.");
        	return;
        }
        if (phone.length() != 10 || !phone.matches("\\d+") || !(phone.startsWith("050") || phone.startsWith("052") || phone.startsWith("053") || phone.startsWith("054") || phone.startsWith("055") || phone.startsWith("058"))) {
        	orderFail("Please enter a valid phone number.");
        	return;
        }

        
        Customer customer = new Customer(name, email, phone);
        Order order = new Order(0,date.toString(),time,guests,confirmation,15,phone,LocalDate.now().toString(),0);
        
        Request tableRequest = new Request("FREE_TABLES",order);
        client.sendToServer(tableRequest);
        
        pendingOrder = order;
        pendingCustomer = customer;
    }
    
    public void handleFreeTables(List<Tables> freeTables) {
    	
    		pendingOrder.setTable_num(freeTables.get(0).getTable_num());
    		Request customerRequest = new Request("INSERT_NEW_CUSTOMER",pendingCustomer);
    		Request orderRequest = new Request("INSERT_NEW_ORDER",pendingOrder);
    		client.sendToServer(customerRequest);
    		client.sendToServer(orderRequest);
    		orderStatusLabel.setText("Order successful.\nYou should recieve a confirmation code on your email!");
    		orderStatusLabel.setStyle("-fx-text-fill: green;");
    	
    }
 
    public void orderFail(String msg) {
        orderStatusLabel.setText(msg);
        orderStatusLabel.setStyle("-fx-text-fill: red;");
    }

    @FXML
    private void goToSubscriberLogin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
    private void checkCode() {
    	try {
    	int conCode = Integer.parseInt(confirmationCodeField.getText());
    	Request r = new Request("CONFIRMATION_CODE",conCode);
    	client.sendToServer(r);
    	} catch(Exception e) {
    		e.printStackTrace();
    		codeStatus("Invalid input.","red");
    	}
    }
    
    public void codeSuccess(OrderCustomer oc) {
        Order order = oc.getOrder();
        Customer customer = oc.getCustomer();

        lostCode.setText("");
        codeStatusLabel.setText("");

        // Clear previous details
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setSpacing(10);
        orderDetailsBox.setPadding(new Insets(10));
        orderDetailsBox.setStyle("-fx-background-color: #f9f9f9; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 5);");

        // Create styled labels
        Label headerLabel = new Label("Welcome " + customer.getCustomer_name() + "!\nHere are your order details:");
        headerLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #333333;");

        Label emailLabel = new Label("Email: " + customer.getCustomer_email());
        emailLabel.setStyle("-fx-text-fill: #555555;");

        Label phoneLabel = new Label("Phone: " + customer.getCustomer_phone());
        phoneLabel.setStyle("-fx-text-fill: #555555;");

        Label numLabel = new Label("Order Number: " + order.getOrder_number());
        numLabel.setStyle("-fx-text-fill: #555555;");

        Label guestsLabel = new Label("Guests: " + order.getNumber_of_guests());
        guestsLabel.setStyle("-fx-text-fill: #555555;");

        Label tableLabel = new Label("Table Number: " + order.getTable_num());
        tableLabel.setStyle("-fx-text-fill: #555555;");

        Label dateLabel = new Label("Date: " + order.getOrder_date());
        dateLabel.setStyle("-fx-text-fill: #555555;");

        Label timeLabel = new Label("Time: " + order.getOrder_time());
        timeLabel.setStyle("-fx-text-fill: #555555;");

        Label placedLabel = new Label("Order Placed On: " + order.getDate_of_placing_order());
        placedLabel.setStyle("-fx-text-fill: #999999; -fx-font-size: 12px;");

        Button cancelBtn = new Button("Cancel Order");
        cancelBtn.setStyle(
            "-fx-background-color: #FF5252; " +
            "-fx-text-fill: white; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5; " +
            "-fx-padding: 6 12 6 12;"
        );
        cancelBtn.setOnAction(e -> cancelOrder());

        codeForCancel = order.getConfirmation_code();

        orderDetailsBox.getChildren().addAll(headerLabel, emailLabel, phoneLabel, numLabel, guestsLabel, tableLabel,dateLabel, timeLabel, placedLabel, cancelBtn);
    }

    
    public void codeStatus(String msg,String color) {
    	orderDetailsBox.getChildren().clear();
        codeStatusLabel.setText(msg);
        codeStatusLabel.setStyle("-fx-text-fill: "+color+";");
    }
    
    public void cancelOrder() {
    	if (codeForCancel!=0) {
        	Request r = new Request("CANCEL_ORDER",codeForCancel);
        	client.sendToServer(r);
    	}
    }
    @FXML
    public void lostCode(MouseEvent event) {
    	lostCode.setText("");
        codeStatusLabel.setText("");
        orderDetailsBox.getChildren().clear();
        orderDetailsBox.setSpacing(10);
        orderDetailsBox.setPadding(new Insets(10));
        orderDetailsBox.setStyle("-fx-background-color: #f9f9f9; -fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.05), 10, 0, 0, 5);");
    	Label emailLabel = new Label("Please enter your email:");
        emailLabel.setStyle("-fx-text-fill: #555555;");
        TextField emailField = new TextField();
        String email = emailField.getText();
        System.out.println(email);
        Button sendBtn = new Button("Send Code");
        sendBtn.setStyle(
            "-fx-background-color: green; " +
            "-fx-text-fill: white; " +
            "-fx-font-weight: bold; " +
            "-fx-background-radius: 5; " +
            "-fx-padding: 6 12 6 12;"
        );
        sendBtn.setOnAction(e -> sendCode(email));
        orderDetailsBox.getChildren().addAll(emailLabel,emailField,sendBtn);
    	
    }
    
    public void sendCode(String email) {
    	if (email == null ||!(email.endsWith("@gmail.com") || email.endsWith("@outlook.com"))) {
        	return;
        }
    	client.sendToServer(new Request("SEND_CODE",email));
    	codeStatus("A code was sent to your email","green"); 
     }
    
    @FXML
    private void refresh() {
    	nameField.clear();
        phoneField.clear();
        emailField.clear();
        confirmationCodeField.clear();
        
        orderStatusLabel.setText("");
        codeStatusLabel.setText("");
        lostCode.setText("");
        
        orderDetailsBox.getChildren().clear();

        guestCountLabel.setText("2");
        datePicker.setValue(null);
        timeSelect.getSelectionModel().clearSelection();
    }
    
    @FXML
    private void exit() {
    	System.exit(0);
    }

}
