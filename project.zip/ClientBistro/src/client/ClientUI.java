package client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ClientUI extends Application {

    public static ClientController chat;

    @Override
    public void start(Stage primaryStage) {
        try {
            chat = new ClientController("localhost", 5555);

            chat.openConnection1();

        } catch (Exception e) {
            System.out.println("❌ Server is OFF, cannot connect");
            showServerError();
            return;   // stop here
        }

        try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/Homepage.fxml"));
        	Parent root = loader.load(); 

        	gui.HomepageController controller = loader.getController();

        	controller.setClient(chat);
            primaryStage.setTitle("Reservations");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();

            primaryStage.setOnCloseRequest(event -> {
                try {
                    if (chat != null)
                        chat.closeConnection();
                } catch (Exception ignored) {}
                System.exit(0);
            });

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Problem loading Homepage.fxml");
        }
    }

    private void showServerError() {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
        alert.setTitle("Connection Failed");
        alert.setHeaderText("Server Not Available");
        alert.setContentText("Please start the server and try again.");
        alert.showAndWait();
        System.exit(0);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
