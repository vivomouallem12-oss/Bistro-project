package Server;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import logic.Customer;
import logic.EmailService;
import logic.Order;
import logic.OrderCustomer;
import logic.Request;
import logic.Response;
import logic.SubscriberLoginRequest;
import logic.Tables;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class EchoServer extends AbstractServer {
	private String emailForCode = null;
    private final Map<ConnectionToClient, String> clientIPs = new ConcurrentHashMap<>();
    private final Map<ConnectionToClient, String> clientHosts = new ConcurrentHashMap<>();

    public EchoServer(int port) {
        super(port);
    }

    @Override
    public void handleMessageFromClient(Object msg, ConnectionToClient client) {

        String ip = clientIPs.getOrDefault(client, "UNKNOWN");
        String host = clientHosts.getOrDefault(client, "UNKNOWN");

        System.out.println("[Client] Message from IP: " + ip + ", Host: " + host);

        MySQLConnectionPool pool = null;
        Connection conn = null;

        try {
            pool = MySQLConnectionPool.getInstance();
            conn = pool.getConnection();
            System.out.println("[DB] Obtained pooled connection");
            
            if (msg instanceof Request r) {
            	
            	// ---------- ADD ORDER ----------
            	if (r.getStatus().equals("INSERT_NEW_ORDER")) {
            		Order o = (Order)r.getData();
            		String sql ="INSERT INTO `order` (order_number,order_date,order_time,number_of_guests,confirmation_code,subscriber_id,customer_number,date_of_placing_order,table_num) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    	ps.setInt(1, o.getOrder_number());
                        ps.setString(2, o.getOrder_date());
                        ps.setString(3, o.getOrder_time());
                        ps.setInt(4, o.getNumber_of_guests());
                        ps.setInt(5, o.getConfirmation_code());
                        ps.setInt(6, o.getSubscriber_id());
                        ps.setString(7, o.getCustomer_number());
                        ps.setString(8, o.getDate_of_placing_order());
                        ps.setInt(9,o.getTable_num());

                        int updated = ps.executeUpdate();

                        if (updated > 0) {
                        	String emailSql = "SELECT customer_email FROM customer WHERE customer_phone = ?";
                        	try (PreparedStatement cps = conn.prepareStatement(emailSql)) {
                        	    cps.setString(1, o.getCustomer_number());
                        	    ResultSet rs = cps.executeQuery();
                        	    if (rs.next()) {
                        	        String emailForCode = rs.getString("customer_email");
                        	        EmailService.sendConfirmationEmail(emailForCode, o.getConfirmation_code());
                        	    } else {
                        	    	System.out.println("[DB] Didnt find customer: "+emailForCode);
                        	    }
                        	}
                        	sendToAllClients("Order inserted successfully!");
                        	System.out.println("[DB] Order inserted: " + o);
                        } else {
                            sendToAllClients("Order not inserted!");
                            System.out.println("[DB] Order not inserted: " + o.getOrder_number());
                        }
                    }
                    
                    
                    
                    
                 // ---------- ADD CUSTOMER ----------
            	} else if (r.getStatus().equals("INSERT_NEW_CUSTOMER")) {
            		Customer c = (Customer)r.getData();
            		String sql ="INSERT INTO customer (customer_name,customer_email,customer_phone) VALUES (?, ?, ?)";

                    try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    	ps.setString(1, c.getCustomer_name());
                        ps.setString(2, c.getCustomer_email());
                        ps.setString(3, c.getCustomer_phone());
                        int updated = ps.executeUpdate();
                        
                        emailForCode = c.getCustomer_email();

                        if (updated > 0) {
                            sendToAllClients("Customer inserted successfully!");
                            System.out.println("[DB] Customer inserted: " + c);
                        } else {
                            sendToAllClients("Customer not inserted!");
                            System.out.println("[DB] Customer not inserted: " + c.getCustomer_name());
                        }
                    }
                    
                 // ---------- CHECK CODE ----------
            	} else if (r.getStatus().equals("CONFIRMATION_CODE")) {
            	    int code = (int) r.getData();

            	    String orderSql = "SELECT * FROM `order` WHERE confirmation_code = ?";

            	    try (PreparedStatement ops = conn.prepareStatement(orderSql)) {

            	        ops.setInt(1, code);

            	        try (ResultSet ors = ops.executeQuery()) {

            	            if (!ors.next()) {
            	                client.sendToClient(new Response("CODE_NOT_FOUND", null));
            	                System.out.println("[Confirmation Code] NOT FOUND");
            	                return;
            	            }

            	            Order o = new Order(
            	                    ors.getInt("order_number"),
            	                    ors.getString("order_date"),
            	                    ors.getString("order_time"),
            	                    ors.getInt("number_of_guests"),
            	                    ors.getInt("confirmation_code"),
            	                    ors.getInt("subscriber_id"),
            	                    ors.getString("customer_number"),
            	                    ors.getString("date_of_placing_order"),
            	                    ors.getInt("table_num")
            	            );

            	            // fetch customer
            	            String custSql = "SELECT * FROM customer WHERE customer_phone = ?";

            	            try (PreparedStatement cps = conn.prepareStatement(custSql)) {

            	                cps.setString(1, ors.getString("customer_number"));

            	                try (ResultSet crs = cps.executeQuery()) {

            	                    Customer c = null;
            	                    if (crs.next()) {
            	                        c = new Customer(
            	                                crs.getString("customer_name"),
            	                                crs.getString("customer_email"),
            	                                crs.getString("customer_phone")
            	                        );
            	                    }
            	                    OrderCustomer oc = new OrderCustomer(o,c);
            	                    Response response = new Response("CODE_FOUND",oc);
            	                    client.sendToClient(response);
            	                    System.out.println("[Confirmation Code] FOUND");
            	                }
            	            }
            	        }
            	    }
            	}
            	
            	
                // ---------- CHECK FREE TABLES ----------
            	else if (r.getStatus().equals("FREE_TABLES")) {

            	    Order o = (Order) r.getData();

            	    int guests = o.getNumber_of_guests();
            	    String date = o.getOrder_date();
            	    String time = o.getOrder_time();

            	    List<Tables> freeTables = new ArrayList<>();
            	    
            	    int tablePlace = 0;
                    if (guests==2) tablePlace = 2;
                    else if (guests>=3 && guests<=4) tablePlace = 4;
                    else if (guests>=5 && guests<=6) tablePlace = 6;
                    else tablePlace = 10;

                    String sql =
                            "SELECT * FROM tables t " +
                            "WHERE t.places = ? " +
                            "AND t.table_num NOT IN ( " +
                            "   SELECT o.table_num FROM `order` o " +
                            "   WHERE o.order_date = ? " +
                            "   AND ( " +
                            "       TIME(?) < ADDTIME(o.order_time, '02:00:00') " +
                            "       AND o.order_time < ADDTIME(TIME(?), '02:00:00') " +
                            "   ) " +
                            ")";

            	    try (PreparedStatement ps = conn.prepareStatement(sql)) {

            	        ps.setInt(1, tablePlace);
            	        ps.setString(2, date);
            	        ps.setString(3, time);
            	        ps.setString(4, time);

            	        try (ResultSet rs = ps.executeQuery()) {
            	            while (rs.next()) {
            	                freeTables.add(new Tables(
            	                    rs.getInt("table_num"),
            	                    rs.getInt("places")
            	                ));
            	            }
            	        }
            	        if (!freeTables.isEmpty()) {
            	            client.sendToClient(new Response("FREE_TABLES_FOUND", freeTables));
            	            System.out.println("[FREE TABLES FOUND] " + freeTables.toString());
            	        } else {
            	            client.sendToClient(new Response("FREE_TABLES_NOT_FOUND", null));
            	            System.out.println("[NO FREE TABLES]");
            	        }

            	    } catch (SQLException e) {
            	        e.printStackTrace();
            	        client.sendToClient(new Response("ERROR", "DB_ERROR"));
            	    }
            	}
            	
                // ---------- CANCEL ORDER ----------
            	else if (r.getStatus().equals("CANCEL_ORDER")) {
            	    int confirmationCode = (int) r.getData();

            	    String customerPhone = null;

            	    // 1. Find reservation
            	    String findSql = "SELECT customer_number FROM `order` WHERE confirmation_code = ?";
            	    try (PreparedStatement ps = conn.prepareStatement(findSql)) {
            	        ps.setInt(1, confirmationCode);
            	        ResultSet rs = ps.executeQuery();
            	        if (rs.next()) customerPhone = rs.getString("customer_number");
            	    }

            	    // 2. Delete order
            	    String deleteOrderSql = "DELETE FROM `order` WHERE confirmation_code = ?";
            	    try (PreparedStatement ps = conn.prepareStatement(deleteOrderSql)) {
            	        ps.setInt(1, confirmationCode);
            	        ps.executeUpdate();
            	    }

            	    // 4. Check remaining orders for customer
            	    int count = 0;
            	    String countSql = "SELECT COUNT(*) FROM `order` WHERE customer_number = ?";
            	    try (PreparedStatement ps = conn.prepareStatement(countSql)) {
            	        ps.setString(1, customerPhone);
            	        ResultSet rs = ps.executeQuery();
            	        if (rs.next()) {
            	            count = rs.getInt(1);
            	        }
            	    }

            	    // 5. Delete customer if no orders left
            	    if (count == 0) {
            	        String deleteCustomerSql = "DELETE FROM customer WHERE customer_phone = ?";
            	        try (PreparedStatement ps = conn.prepareStatement(deleteCustomerSql)) {
            	            ps.setString(1, customerPhone);
            	            ps.executeUpdate();
            	        }
            	    }

            	    client.sendToClient(new Response("CANCEL_SUCCESS",null));
            	    System.out.println("[CANCEL] Order with confirmation code "+confirmationCode+" canceled successfully");
            	}

            }


            // ---------- SUBSCRIBER LOGIN ----------
            else if (msg instanceof SubscriberLoginRequest req) {

                System.out.println("[Login] Subscriber: "
                        + req.getSubscriberId()
                        + " Code: "
                        + req.getConfirmationCode());

                String sql = "SELECT * FROM `order` WHERE subscriber_id = ? AND confirmation_code = ?";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {

                    ps.setString(1, req.getSubscriberId());
                    ps.setString(2, req.getConfirmationCode());

                    try (ResultSet rs = ps.executeQuery()) {

                        if (rs.next()) {
                            client.sendToClient("SUBSCRIBER_OK");
                            System.out.println("[Login] SUCCESS");
                        } else {
                            client.sendToClient("SUBSCRIBER_FAIL");
                            System.out.println("[Login] FAILED");
                        }
                    }
                }
            }
            else {
                System.out.println("[Warning] Unknown message type: " + msg);
            }
        
        } catch (Exception ex) {
            ex.printStackTrace();
            try { client.sendToClient("SUBSCRIBER_ERROR"); } catch (Exception ignored) {}
        }

        finally {
            if (pool != null && conn != null) {
                pool.releaseConnection(conn);
                System.out.println("[Pool] Connection returned");
            }
        }
    }
    
    private void triggers() throws SQLException {
    	MySQLConnectionPool pool = MySQLConnectionPool.getInstance();;
        Connection conn = pool.getConnection();
        try {
            conn.setAutoCommit(false);

            String deleteOrdersSQL = "DELETE FROM `order` WHERE TIMESTAMP(order_date, order_time) < NOW() - INTERVAL 2 HOUR";
            int deletedOrders;
            try (PreparedStatement ps = conn.prepareStatement(deleteOrdersSQL)) {
                deletedOrders = ps.executeUpdate();
                System.out.println("[CLEANUP] Deleted orders: " + deletedOrders);
            }

            String deleteCustomersSQL = "DELETE FROM customer WHERE customer_phone NOT IN (SELECT DISTINCT customer_phone FROM `order`)";
            try (PreparedStatement ps = conn.prepareStatement(deleteCustomersSQL)) {
                int deletedCustomers = ps.executeUpdate();
                System.out.println("[CLEANUP] Deleted customers with no orders: " + deletedCustomers);
            }
            
            String sql = "SELECT c.customer_email FROM `order` o JOIN customer c ON c.customer_phone = o.customer_number WHERE TIMESTAMP(o.order_date, o.order_time) BETWEEN NOW() AND NOW() + INTERVAL 2 HOUR";
            try (PreparedStatement ps = conn.prepareStatement(sql);
            	ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    EmailService.sendReminderEmail(rs.getString("customer_email"));
                    System.out.println("[REMINDER] Sent reminder to: " + rs.getString("customer_email"));
                 }
            }
            
            
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.close();
        }
    }


    // ===== SERVER EVENTS =====
    @Override
    protected void serverStarted() {
        System.out.println("[Server] Listening on port " + getPort());
        try {
            MySQLConnection.getInstance();
            MySQLConnectionPool.getInstance();
            System.out.println("[Pool] Ready");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

        scheduler.scheduleAtFixedRate(() -> {
            try {
            	triggers();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 0, 10, TimeUnit.MINUTES);
    }

    @Override
    protected void serverStopped() {
        System.out.println("[Server] Stopped listening.");
    }

    @Override
    protected void clientConnected(ConnectionToClient client) {
        try {
            String ip = client.getInetAddress().getHostAddress();
            String host = client.getInetAddress().getHostName();

            clientIPs.put(client, ip);
            clientHosts.put(client, host);

            System.out.println("[Client] Connected - " + ip);
        } catch (Throwable ignored) {}
    }

    @Override
    protected synchronized void clientDisconnected(ConnectionToClient client) {
        if (client == null) return;

        String ip = clientIPs.getOrDefault(client, "UNKNOWN");
        System.out.println("[Client] Disconnected - " + ip);

        clientIPs.remove(client);
        clientHosts.remove(client);
    }

    @Override
    protected synchronized void clientException(ConnectionToClient client, Throwable ex) {
        if (client == null) return;
        System.out.println("[Client] Crashed: " + ex.getMessage());
    }
}
