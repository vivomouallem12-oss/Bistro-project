package Server;

import java.io.IOException;
import java.sql.*;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import logic.Customer;
import logic.Order;
import logic.SubscriberLoginRequest;
import ocsf.server.AbstractServer;
import ocsf.server.ConnectionToClient;

public class EchoServer extends AbstractServer {

    private final Map<ConnectionToClient, String> clientIPs = new ConcurrentHashMap<>();
    private final Map<ConnectionToClient, String> clientHosts = new ConcurrentHashMap<>();

    public EchoServer(int port) {
        super(port);
    }

    @Override
    public void handleMessageFromClient(Object msg, ConnectionToClient client) {

        String ip = clientIPs.getOrDefault(client, "UNKNOWN");
        String host = clientHosts.getOrDefault(client, "UNKNOWN");

        System.out.println("[Client] Message from IP: " + ip + ", Host: " + host);

        MySQLConnectionPool pool = null;
        Connection conn = null;

        try {
            pool = MySQLConnectionPool.getInstance();
            conn = pool.getConnection();
            System.out.println("[DB] Obtained pooled connection");
            
            if (msg instanceof Order o) {
            	String sql ="INSERT INTO `order` (order_number,order_date,order_time,number_of_guests,confirmation_code,subscriber_id,date_of_placing_order,table_num) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                	ps.setInt(1, o.getOrder_number());
                    ps.setString(2, o.getOrder_date());
                    ps.setString(3, o.getOrder_time());
                    ps.setInt(4, o.getNumber_of_guests());
                    ps.setInt(5, o.getConfirmation_code());
                    ps.setInt(6, o.getSubscriber_id());
                    ps.setString(7, o.getDate_of_placing_order());
                    ps.setInt(8,o.getTable_num());

                    int updated = ps.executeUpdate();

                    if (updated > 0) {
                        sendToAllClients("Order inserted successfully!");
                        System.out.println("[DB] Order inserted: " + o);
                    } else {
                        sendToAllClients("Order not inserted!");
                        System.out.println("[DB] Order not inserted: " + o.getOrder_number());
                    }
                }
            }
            if (msg instanceof Customer c) {
            	String sql ="INSERT INTO customer (customer_name,customer_email,customer_phone) VALUES (?, ?, ?)";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                	ps.setString(1, c.getCustomer_name());
                    ps.setString(2, c.getCustomer_email());
                    ps.setString(3, c.getCustomer_phone());
                    int updated = ps.executeUpdate();

                    if (updated > 0) {
                        sendToAllClients("Order updated successfully!");
                        System.out.println("[DB] Order updated: " + c);
                    } else {
                        sendToAllClients("Order not found!");
                        System.out.println("[DB] Order not found: " + c.getCustomer_name());
                    }
                }
            }

            // ---------- GET ALL ORDERS ----------
            if (msg instanceof String s) {

                if ("getOrders".equals(s)) {

                    String sql = "SELECT * FROM `order`";

                    try (Statement stmt = conn.createStatement();
                         ResultSet rs = stmt.executeQuery(sql)) {

                        while (rs.next()) {
                            Order o = new Order(
                                    rs.getInt("order_number"),
                                    rs.getString("order_date"),
                                    rs.getString("order_time"),
                                    rs.getInt("number_of_guests"),
                                    rs.getInt("confirmation_code"),
                                    rs.getInt("subscriber_id"),
                                    rs.getString("date_of_placing_order"),
                                    rs.getInt("table_num")
                            );

                            client.sendToClient(o);
                            System.out.println("[Server → Client] Sent: " + o);
                        }
                    }
                }

                else {
                    try {
                        int orderNum = Integer.parseInt(s);
                        fetchSingleOrder(conn, orderNum, client);
                    } catch (NumberFormatException e) {
                        System.out.println("[Warning] Unknown string command: " + s);
                    }
                }
            }

            // ---------- INTEGER ORDER REQUEST ----------
            else if (msg instanceof Integer orderNum) {
                fetchSingleOrder(conn, orderNum, client);
            }
            
            // ---------- UPDATE ORDER ----------
            else if (msg instanceof Order o) {

                String sql =
                        "UPDATE `order` SET order_date=?, number_of_guests=? WHERE order_number=?";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, o.getOrder_date());
                    ps.setInt(2, o.getNumber_of_guests());
                    ps.setInt(3, o.getOrder_number());

                    int updated = ps.executeUpdate();

                    if (updated > 0) {
                        sendToAllClients("Order updated successfully!");
                        System.out.println("[DB] Order updated: " + o);
                    } else {
                        sendToAllClients("Order not found!");
                        System.out.println("[DB] Order not found: " + o.getOrder_number());
                    }
                }
                
            }

            // ---------- SUBSCRIBER LOGIN ----------
            else if (msg instanceof SubscriberLoginRequest req) {

                System.out.println("[Login] Subscriber: "
                        + req.getSubscriberId()
                        + " Code: "
                        + req.getConfirmationCode());

                String sql =
                        "SELECT * FROM `order` WHERE subscriber_id = ? AND confirmation_code = ?";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {

                    ps.setString(1, req.getSubscriberId());
                    ps.setString(2, req.getConfirmationCode());

                    try (ResultSet rs = ps.executeQuery()) {

                        if (rs.next()) {
                            client.sendToClient("SUBSCRIBER_OK");
                            System.out.println("[Login] SUCCESS");
                        } else {
                            client.sendToClient("SUBSCRIBER_FAIL");
                            System.out.println("[Login] FAILED");
                        }
                    }
                }
            }

            else {
                System.out.println("[Warning] Unknown message type: " + msg);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            try { client.sendToClient("SUBSCRIBER_ERROR"); } catch (Exception ignored) {}
        }

        finally {
            if (pool != null && conn != null) {
                pool.releaseConnection(conn);
                System.out.println("[Pool] Connection returned");
            }
        }
    }

    private void fetchSingleOrder(Connection conn, int orderNum, ConnectionToClient client) throws IOException {

        String sql = "SELECT * FROM `order` WHERE order_number = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderNum);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                	Order o = new Order(
                            rs.getInt("order_number"),
                            rs.getString("order_date"),
                            rs.getString("order_time"),
                            rs.getInt("number_of_guests"),
                            rs.getInt("confirmation_code"),
                            rs.getInt("subscriber_id"),
                            rs.getString("date_of_placing_order"),
                            rs.getInt("table_num")
                    );

                    client.sendToClient(o);
                    System.out.println("[Server → Client] Sent single order");
                }

                else {
                    client.sendToClient(new Order(-1, null,null, 0, 0, 0, null,0));
                    System.out.println("[DB] Order not found: " + orderNum);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ===== SERVER EVENTS =====
    @Override
    protected void serverStarted() {
        System.out.println("[Server] Listening on port " + getPort());
        try {
            MySQLConnection.getInstance();
            MySQLConnectionPool.getInstance();
            System.out.println("[Pool] Ready");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void serverStopped() {
        System.out.println("[Server] Stopped listening.");
    }

    @Override
    protected void clientConnected(ConnectionToClient client) {
        try {
            String ip = client.getInetAddress().getHostAddress();
            String host = client.getInetAddress().getHostName();

            clientIPs.put(client, ip);
            clientHosts.put(client, host);

            System.out.println("[Client] Connected - " + ip);
        } catch (Throwable ignored) {}
    }

    @Override
    protected synchronized void clientDisconnected(ConnectionToClient client) {
        if (client == null) return;

        String ip = clientIPs.getOrDefault(client, "UNKNOWN");
        System.out.println("[Client] Disconnected - " + ip);

        clientIPs.remove(client);
        clientHosts.remove(client);
    }

    @Override
    protected synchronized void clientException(ConnectionToClient client, Throwable ex) {
        if (client == null) return;
        System.out.println("[Client] Crashed: " + ex.getMessage());
    }
}
