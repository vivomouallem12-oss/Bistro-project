package gui;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import logic.Customer;
import logic.Order;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Random;

import client.ClientController;

public class HomepageController {
	
	 private ClientController client;

    @FXML
    private Label guestCountLabel;

    @FXML
    private Button minusGuestBtn, plusGuestBtn, orderBtn, subscriberBtn;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<String> timeSelect;

    @FXML
    private TextField nameField, phoneField, emailField;

    private int guests = 2;
    
    public void setClient(ClientController client) {
        this.client = client;
    }



    @FXML
    private void incGuests() {
        if (guests < 20) guests++;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void decGuests() {
        if (guests > 1) guests--;
        guestCountLabel.setText(String.valueOf(guests));
    }

    @FXML
    private void handleOrder() {
    	Random r = new Random();
    	int confirmation = r.nextInt((999999 - 100000)+1)+100000;
        LocalDate date = datePicker.getValue();
        String time = timeSelect.getValue();
        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();

        Customer customer = new Customer(name, email, phone);
        Order order = new Order(25,date.toString(),time,guests,confirmation,15,LocalDate.now().toString(),0);

        // For demo purposes, show an alert
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reservation Created");
        System.out.println(
            "Reservation for " + customer.getCustomer_name() + "\n" +
            "Guests: " + order.getNumber_of_guests() + "\n" +
            "Order: " + order.getOrder_date() + "\n" +
            "TimeNow: " + order.getOrder_time() + "\n" +
            "Phone: " + customer.getCustomer_phone()+ "\n" +
            "Email: " + customer.getCustomer_email()
        );
        
        client.sendToServer(order);
        client.sendToServer(customer);
    }

    @FXML
    private void goToSubscriberLogin(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
