package logic;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class SpecialDayDTO implements Serializable {
    public LocalDate date;
    public boolean allDayClose;
    public LocalTime start;
    public LocalTime end;
    public String reason;

    public SpecialDayDTO(LocalDate date, boolean allDayClose, LocalTime start, LocalTime end, String reason) {
        this.date = date;
        this.allDayClose = allDayClose;
        this.start = start;
        this.end = end;
        this.reason = reason;
    }
}
