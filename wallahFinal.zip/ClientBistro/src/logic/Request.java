package logic;

import java.io.Serializable;

public class Request implements Serializable {

    private static final long serialVersionUID = 1L;

    private String status;
    private Object data;
    private Object extraData; // optional

    // Old constructor (kept for backward compatibility)
    public Request(String status, Object data) {
        this.status = status;
        this.data = data;
        this.extraData = null;
    }

    // New constructor (optional extra payload)
    public Request(String status, Object data, Object extraData) {
        this.status = status;
        this.data = data;
        this.extraData = extraData;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public Object getExtraData() {
        return extraData;
    }

    public void setExtraData(Object extraData) {
        this.extraData = extraData;
    }
}
