package logic;

public class Payment {
	
	private int payment_id;
	private int order_number;
	private double amount;
	public Payment(int payment_id, int order_number, double amount) {
		super();
		this.payment_id = payment_id;
		this.order_number = order_number;
		this.amount = amount;
	}
	public int getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}
	public int getOrder_number() {
		return order_number;
	}
	public void setOrder_number(int order_number) {
		this.order_number = order_number;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Payment [payment_id=" + payment_id + ", order_number=" + order_number + ", amount=" + amount + "]";
	}
	
	

}
