package logic;

import java.io.Serializable;

public class Staff implements Serializable {

    private int staffId;
    private String username;
    private String role; // MANAGER / REPRESENTATIVE

    public Staff(int staffId, String username, String role) {
        this.staffId = staffId;
        this.username = username;
        this.role = role;
    }

    public int getStaffId() { return staffId; }
    public String getUsername() { return username; }
    public String getRole() { return role; }
}
