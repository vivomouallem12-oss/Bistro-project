package gui;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import logic.Request;
import logic.Subscriber;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import navigation.Navigation;

public class RegisterSubscriberController {

    public static RegisterSubscriberController activeController;

    @FXML private TextField nameField;
    @FXML private TextField phoneField;
    @FXML private TextField emailField;

    @FXML private Label resultLabel;
    @FXML private ImageView qrImageView;

    @FXML private Button exitBtn, backBtn;

    @FXML
    public void initialize() {
        activeController = this;
    }

    // ================= CREATE SUBSCRIBER =================

    @FXML
    private void createSubscriber() {

        String name = nameField.getText();
        String phone = phoneField.getText();
        String email = emailField.getText();

        if (name.isEmpty() || phone.isEmpty() || email.isEmpty()) {
            resultLabel.setText("Please fill all fields");
            return;
        }

        Subscriber sub = new Subscriber(0, name, email, phone);

        ClientUI.chat.sendToServer(
                new Request("REGISTER_SUBSCRIBER", sub)
        );

        resultLabel.setText("Creating subscriber...");
    }

    // ================= SERVER CALLBACK =================

    public void showSuccess(String displayId) {
        generateQRCode(displayId);
    }

    // ================= QR GENERATION =================

    private void generateQRCode(String subscriberId) {
        try {
            String data = "SUBSCRIBER_ID:" + subscriberId;

            BitMatrix matrix = new MultiFormatWriter()
                    .encode(data, BarcodeFormat.QR_CODE, 250, 250);

            Path path = Paths.get("qr_" + subscriberId + ".png");
            MatrixToImageWriter.writeToPath(matrix, "PNG", path);

            Image qrImage = new Image(path.toUri().toString());
            qrImageView.setImage(qrImage);

            resultLabel.setText(
                "Subscriber created!\nID: " + subscriberId +
                "\nQR saved as: " + path.getFileName()
            );

        } catch (Exception e) {
            e.printStackTrace();
            resultLabel.setText("Subscriber created, but QR failed.");
        }
    }

    // ================= EXIT =================

    @FXML
    private void exit() {
        System.exit(0);
    }

    // ================= BACK (SMART NAVIGATION) =================

    @FXML
    private void back(ActionEvent event) {
        try {
            String target;

            if (Navigation.getRoleSelectionScreen()
                    .equals("RoleSelectionTerminal.fxml")) {

                // Came from Terminal mode
                target = "RepresentativeHomepage.fxml";

            } else {
                // Came from App mode
                target = "ManagerHomePage.fxml";
            }

            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + target)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}