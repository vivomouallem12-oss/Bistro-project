package gui;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import logic.Subscriber;

import java.io.ByteArrayInputStream;

public class SubscriberQRController {

    @FXML
    private ImageView imgQRCode;

    private Subscriber subscriber;

    public void setSubscriber(Subscriber subscriber) {
        this.subscriber = subscriber;
        generateQR();
    }

    private void generateQR() {
        try {
            if (subscriber == null) return;

            // Get QR as byte array from your logic class
            // Example: QRLogic.generateQR(subscriber.getSubscriberId());
            byte[] qrBytes = logic.QRService.generateQRImageBytes(subscriber.getSubscriberId() + "");

            Image qrImage = new Image(new ByteArrayInputStream(qrBytes));
            imgQRCode.setImage(qrImage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}