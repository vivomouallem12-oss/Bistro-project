package gui;

import client.ChatClient;
import client.ClientUI;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import navigation.Navigation;

public class RoleSelectionAppController {

    @FXML
    private AnchorPane anchorPane;

    @FXML private StackPane guestCard;
    @FXML private StackPane subscriberCard;
    @FXML private StackPane agentCard;
    @FXML private StackPane managerCard;

    @FXML
    public void initialize() {
        applyHoverEffect(guestCard);
        applyHoverEffect(subscriberCard);
        applyHoverEffect(agentCard);
        applyHoverEffect(managerCard);

        // 🔥 IMPORTANT: Set APP mode
        Navigation.setMode(Navigation.Mode.APP);
    }

    // ================= ROUTING =================

    @FXML
    private void onGuestClicked() {
    	   try {
               FXMLLoader loader =
                       new FXMLLoader(getClass().getResource("/gui/Reservation.fxml"));
               Parent root = loader.load();

               ReservationController controller = loader.getController();
               controller.setClient(ClientUI.chat);
               ChatClient.setActiveReservationHandler(controller);

               anchorPane.getScene().setRoot(root);

           } catch (Exception e) {
               e.printStackTrace();
           }
    }

    @FXML
    private void onSubscriberClicked() {
    	  try {
              FXMLLoader loader =
                      new FXMLLoader(getClass().getResource("/gui/SubscriberLogin.fxml"));
              Parent root = loader.load();

              SubscriberLoginController controller = loader.getController();
              controller.setClient(ClientUI.chat);
             // ChatClient.setActiveReservationHandler(controller);

              anchorPane.getScene().setRoot(root);

          } catch (Exception e) {
              e.printStackTrace();
          }
    }

    @FXML
    private void onAgentClicked() {
        loadScreen("RepresentativeLogin.fxml");
    }

    @FXML
    private void onManagerClicked() {
        loadScreen("ManagerLogin.fxml");
    }

    /* ================= BACK ================= */
    @FXML
    private void back() {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/Interface.fxml")
            );
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= EXIT ================= */
    @FXML
    private void exit() {
        System.exit(0);
    }

    // ================= HELPERS =================

    private void loadScreen(String fxml) {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + fxml)
            );
            anchorPane.getScene().setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void applyHoverEffect(StackPane card) {
        card.setOnMouseEntered(e -> {
            card.setScaleX(1.05);
            card.setScaleY(1.05);
        });

        card.setOnMouseExited(e -> {
            card.setScaleX(1.0);
            card.setScaleY(1.0);
        });
    }
}
