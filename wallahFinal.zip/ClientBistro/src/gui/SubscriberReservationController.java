package gui;

import client.ClientController;
import client.ClientUI;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import logic.Order;
import logic.Request;
import logic.SpecialDayDTO;
import logic.Subscriber;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SubscriberReservationController {

    private ClientController client;
 // Keeps track of days fully closed (all slots booked or all-day closed)
    private final Map<LocalDate, Boolean> closedDays = new HashMap<>();

    private final Map<LocalDate, SpecialDayDTO> specialMap = new HashMap<>();

    @FXML private Label lblWelcome, lblGuests, lblName, lblEmail, lblPhone,lblSubscriberId;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox<String> timeBox;
    @FXML private TextField txtConfirmationCode;
    @FXML private ComboBox<String> cbMyOrders; // NEW: ComboBox for active reservations

    private int guests = 2;
    private Subscriber currentSubscriber;
    private Order pendingOrder;

    private static SubscriberReservationController ACTIVE;

    // Formatter for LocalTime -> HH:mm
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");

    /* ================= INIT ================= */
    public void setClient(ClientController client) {
        this.client = client;
        datePicker.setValue(LocalDate.now());
        
        LocalDate from = LocalDate.now();
        LocalDate to = from.plusMonths(2); // look ahead 2 months
        client.sendToServer(new Request("GET_SPECIALDAYS_RANGE", List.of(from, to)));

    }

    @FXML
    public void initialize() {
        // Make this controller accessible globally
        ACTIVE = this;

        // Set initial guest count
        lblGuests.setText(String.valueOf(guests));

        // Disable typing in datePicker
        datePicker.setEditable(false);

        // Listener for date selection
        datePicker.valueProperty().addListener((obs, oldDate, newDate) -> {
            // Clear times first
            timeBox.getItems().clear();

            if (newDate != null) {
                // Send LocalDate to server
                ClientUI.chat.sendToServer(new Request("GET_HOURS", newDate));
            }
        });

        // Optionally, request hours for today at startup
        Platform.runLater(() -> {
            LocalDate today = LocalDate.now();
            datePicker.setValue(today);
            ClientUI.chat.sendToServer(new Request("GET_HOURS", today));
        });
    }



    public static SubscriberReservationController getActive() {
        return ACTIVE;
    }

    public void setSubscriber(Subscriber sub) {
        this.currentSubscriber = sub;

        lblWelcome.setText("Welcome back, " + sub.getUsername());
        lblName.setText(sub.getUsername());
        lblEmail.setText(sub.getEmail());
        lblPhone.setText(sub.getPhone());
        lblSubscriberId.setText(String.valueOf(currentSubscriber.getSubscriberId()));

        // Request active reservations for ComboBox
        ClientUI.chat.sendToServer(
                new Request("GET_ACTIVE_ORDERS", currentSubscriber.getSubscriberId())
        );
    }
    
    
    //added for test
    
    public void loadSpecialDays(List<SpecialDayDTO> list) {
        specialMap.clear();
        for (SpecialDayDTO sd : list) {
            specialMap.put(sd.date, sd);
        }
        updateDatePickerCells();
    }
    private void updateDatePickerCells() {
        datePicker.setDayCellFactory(dp -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);

                if (empty || date == null) return;

                // Disable past dates
                if (date.isBefore(LocalDate.now())) {
                    setDisable(true);
                    setStyle("-fx-background-color: #dddddd;");
                    return;
                }

                // Disable fully closed days
                if (closedDays.getOrDefault(date, false)) {
                    setDisable(true);
                    setStyle("-fx-background-color: #000000; -fx-text-fill: white;");
                    setTooltip(new Tooltip("Restaurant closed / no available slots"));
                } else {
                    setDisable(false);
                    setStyle(null);
                    setTooltip(null);
                }
            }
        });
    }

    private void onDateSelected(LocalDate date) {
        timeBox.getItems().clear();

        // Fully closed?
        SpecialDayDTO sd = specialMap.get(date);
        if (sd != null && sd.allDayClose) {
            showInfo("Restaurant is closed: " + (sd.reason != null ? sd.reason : ""));
            datePicker.setValue(null);
            return;
        }

        // Special hours
        if (sd != null && sd.start != null && sd.end != null) {
            List<String> slots = buildSlotsFromSpecialDay(sd);
            if (!slots.isEmpty()) {
                timeBox.getItems().setAll(slots);
                timeBox.setValue(slots.get(0));
                return;
            }
        }

        // Otherwise, get regular hours from server
        if (client != null) {
            client.sendToServer(new Request("GET_HOURS", date));
        }
    }
    private List<String> buildSlotsFromSpecialDay(SpecialDayDTO sd) {
        List<String> slots = new ArrayList<>();
        LocalTime t = sd.start;
        while (!t.isAfter(sd.end.minusMinutes(30))) {
            slots.add(t.format(DateTimeFormatter.ofPattern("HH:mm")));
            t = t.plusMinutes(30);
        }
        return slots;
    }


    /* ================= POPULATE ACTIVE ORDERS ================= */
    public void populateOrders(List<String> orders) {
        Platform.runLater(() -> {
            cbMyOrders.getItems().clear();
            cbMyOrders.getItems().addAll(orders);
        });
    }


    /* ================= GUESTS ================= */
    @FXML private void incGuests() {
        if (guests < 10) guests++;
        lblGuests.setText(String.valueOf(guests));
    }

    @FXML private void decGuests() {
        if (guests > 1) guests--;
        lblGuests.setText(String.valueOf(guests));
    }

    /* ================= RESERVE ================= */
    @FXML private void onReserve() {
        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        Order order = new Order(
                0,
                datePicker.getValue().toString(),
                timeBox.getValue(),
                guests,
                0,
                currentSubscriber.getSubscriberId(),
                currentSubscriber.getUsername(),
                currentSubscriber.getPhone(),
                currentSubscriber.getEmail(),
                LocalDate.now().toString(),
                0,
                "BOOKED",
                null,
                false
        );

        pendingOrder = order;

        ClientUI.chat.sendToServer(
                new Request("CHECK_AVAILABILITY", order)
        );
    }

    public void sendCreateReservation() {
        if (pendingOrder == null) {
            showError("No pending order found. Please click Reserve again.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("CREATE_RESERVATION", pendingOrder)
        );
    }

    /* ================= CANCEL RESERVATION ================= */
    @FXML private void onCancelReservation() {
        if (txtConfirmationCode.getText().isBlank()) {
            showError("Please enter confirmation code.");
            return;
        }

        int code;
        try {
            code = Integer.parseInt(txtConfirmationCode.getText().trim());
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Cancel Reservation");
        confirm.setHeaderText("Are you sure?");
        confirm.setContentText("This will cancel your reservation.\nConfirmation Code: " + code);

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) return;

        ClientUI.chat.sendToServer(
                new Request("CANCEL_ORDER", code)
        );
    }

    /* ================= SUGGESTED TIMES ================= */
    public void showSuggestedTimes(List<LocalTime> times) {
        Platform.runLater(() -> {
            if (times == null || times.isEmpty()) {
                showInfo("Sorry, no tables are available at your selected time.");
                return;
            }
            String timesStr = times.stream()
                                   .map(t -> t.format(timeFormatter))
                                   .collect(Collectors.joining(", "));
            showInfo("No tables available at your selected time.\nSuggested times:\n" + timesStr);
        });
    }

    /* ================= CHECK IN ================= */
    @FXML
    private void onCheckIn() {
        String codeStr = txtConfirmationCode.getText().trim();

        // If nothing typed, check ComboBox selection
        if (codeStr.isBlank()) {
            String selected = cbMyOrders.getValue();
            if (selected != null && !selected.isBlank()) {
                // Use regex to extract digits after "Code:"
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("Code:\\s*(\\d+)").matcher(selected);
                if (m.find()) {
                    codeStr = m.group(1); // Only digits
                    txtConfirmationCode.setText(codeStr);
                    //System.out.println(codeStr);
                }
            }
        }

        if (codeStr.isBlank()) {
            showError("Please enter or select a confirmation code.");
            return;
        }

        try {
            int code = Integer.parseInt(codeStr);
            ClientUI.chat.sendToServer(
                    new Request("TERMINAL_CHECKIN", code)
            );
        } catch (NumberFormatException e) {
            showError("Confirmation code must be numbers only.");
        }
    }



    @FXML private void onForgotConfirmationCode() {
        if (currentSubscriber == null) {
            showError("Subscriber not loaded.");
            return;
        }

        ClientUI.chat.sendToServer(
                new Request("LOST_CONFIRMATION_CODE", currentSubscriber.getSubscriberId())
        );
    }

    /* ================= SERVER CALLBACKS ================= */
    public void handleCheckInSuccess(int tableNum, int code) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Check-In Successful");
        alert.setHeaderText("Welcome! Your table is ready ✅");
        alert.setContentText("Confirmation Code: " + code + "\nPlease go to Table #" + tableNum + ".\nEnjoy your meal!");
        alert.showAndWait();
        
        // Just reset the input fields, do NOT open a new scene
        resetCheckInInput();
    }


    public void handleCheckInWait() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("No Table Available Yet");
        alert.setHeaderText("Please wait ⏳");
        alert.setContentText("All matching tables are currently occupied.\nWe will notify you as soon as a table is free.");
        alert.showAndWait();
        resetCheckInInput();
    }

    public void handleCheckInError(String msg) {
        showError(msg);
        resetCheckInInput();
    }

    /* ================= BACK / EDIT INFO ================= */
    @FXML private void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));
            Parent root = loader.load();
            SubscriberMainController ctrl = loader.getController();
            ctrl.setClient(ClientUI.chat);
            ctrl.setSubscriber(currentSubscriber);
            Stage stage = (Stage) lblGuests.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML private void onEditPhone() {
        TextInputDialog dialog = new TextInputDialog(lblPhone.getText());
        dialog.setTitle("Edit Phone");
        dialog.setHeaderText("Change your phone number");
        dialog.setContentText("New phone:");
        dialog.showAndWait().ifPresent(newPhone -> {
            if (!newPhone.matches("\\d{9,10}")) { showError("Invalid phone number."); return; }
            ClientUI.chat.sendToServer(
                    new Request("UPDATE_SUBSCRIBER_PHONE",
                            Map.of("subscriberId", currentSubscriber.getSubscriberId(), "phone", newPhone))
            );
        });
    }

    @FXML private void onEditEmail() {
        TextInputDialog dialog = new TextInputDialog(lblEmail.getText());
        dialog.setTitle("Edit Email");
        dialog.setHeaderText("Change your email");
        dialog.setContentText("New email:");
        dialog.showAndWait().ifPresent(newEmail -> {
            if (!newEmail.contains("@")) { showError("Invalid email."); return; }
            ClientUI.chat.sendToServer(
                    new Request("UPDATE_SUBSCRIBER_EMAIL",
                            Map.of("subscriberId", currentSubscriber.getSubscriberId(), "email", newEmail))
            );
        });
    }

    /* ================= HELPERS ================= */
    private void resetCheckInInput() {
        txtConfirmationCode.clear();
        cbMyOrders.getSelectionModel().clearSelection();
        txtConfirmationCode.requestFocus();
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.showAndWait();
    }

    private void showInfo(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.showAndWait();
    }

    @FXML private void refresh() { }

    @FXML private void exit() { System.exit(0); }

    @FXML private void back(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/SubscriberMain.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* ================= TIME PICKER ================= */
    public void updateTimes(String openClose) {
        Platform.runLater(() -> {
            LocalDate date = datePicker.getValue();
            timeBox.getItems().clear();

            if (openClose == null || openClose.isBlank()) {
                // Day has no slots → mark as closed
                closedDays.put(date, true);

                // Deselect the date so user doesn't stay on a closed day
                datePicker.setValue(null);

                // Refresh cells to turn the day black
                updateDatePickerCells();

                showInfo("Selected day has no available reservation slots.");
                return;
            } else {
                closedDays.put(date, false);
            }

            String[] parts = openClose.split(" ");
            LocalTime open = LocalTime.parse(parts[0]);
            LocalTime close = LocalTime.parse(parts[1]);

            LocalTime t = open;
            while (!t.isAfter(close.minusMinutes(30))) {
                timeBox.getItems().add(t.format(DateTimeFormatter.ofPattern("HH:mm")));
                t = t.plusMinutes(30);
            }

            if (!timeBox.getItems().isEmpty()) timeBox.setValue(timeBox.getItems().get(0));

            updateDatePickerCells(); // refresh visual style
        });
    }





    /* ================= APPLY UPDATES ================= */
    public void applyUpdatedEmail(String newEmail) {
        lblEmail.setText(newEmail);
        currentSubscriber.setEmail(newEmail);
    }

    public void applyUpdatedPhone(String newPhone) {
        lblPhone.setText(newPhone);
        currentSubscriber.setPhone(newPhone);
    }

    public void updateEmailLabel(String newEmail) { lblEmail.setText(newEmail); }
    public void updatePhoneLabel(String newPhone) { lblPhone.setText(newPhone); }
    public void codeStatus(String msg, String color) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg);
        a.showAndWait();
    }
}
