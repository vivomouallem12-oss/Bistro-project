package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logic.OpenHours;
import logic.Request;
import logic.SpecialDayDTO;
import navigation.Navigation;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

import client.ClientUI;


public class OpeningHoursController {

    @FXML
    private ComboBox<String> dayBox;

    @FXML
    private TextField openField;

    @FXML
    private TextField closeField;
    
    @FXML
    private TextField reason;

    @FXML
    private Label statusLabel;
    
    @FXML 
    private Button backBtn,exitBtn,deleteBtn;
    
    @FXML
    private DatePicker specialDate;

    @FXML
    public void initialize() {
        dayBox.getItems().addAll(
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Holiday / Special Day"
        );

        // hide special fields by default
        specialDate.setVisible(false);
        specialDate.setManaged(false);
        reason.setVisible(false);
        reason.setManaged(false);
        deleteBtn.setVisible(false);
        deleteBtn.setManaged(false);

        dayBox.valueProperty().addListener((obs, oldVal, newVal) -> {
            boolean isHoliday = "Holiday / Special Day".equals(newVal);

            specialDate.setVisible(isHoliday);
            specialDate.setManaged(isHoliday);
            reason.setVisible(isHoliday);
            reason.setManaged(isHoliday);
            deleteBtn.setVisible(isHoliday);
            deleteBtn.setManaged(isHoliday);
            
        });
    }


    @FXML
    private void saveHours() {

        String dayStr = dayBox.getValue();
        if (dayStr == null) {
            statusLabel.setText("Please choose a day");
            return;
        }

        boolean isHoliday = dayStr.equals("Holiday / Special Day");

        LocalTime open = parseTime(openField);
        LocalTime close = parseTime(closeField);

        // ========================
        // HOLIDAY / SPECIAL DAY
        // ========================
        if (isHoliday) {
            LocalDate date = specialDate.getValue();
            String txt = reason.getText();

            if (date == null) {
                statusLabel.setText("Please choose a date");
                return;
            }

            boolean closedAllDay = (open == null || close == null);

            SpecialDayDTO sd = new SpecialDayDTO(
                date,
                closedAllDay,
                open,
                close,
                txt
            );

            ClientUI.chat.sendToServer(new Request("SET_SPECIAL_DAY", sd));
            statusLabel.setText("Special day saved");
            return;
        }

        // ========================
        // NORMAL WEEK DAY
        // ========================
        if (open == null || close == null) {
            statusLabel.setText("Opening and closing times are required");
            return;
        }

        int day = convertDayToInt(dayStr);

        OpenHours hours = new OpenHours(day, open.toString(), close.toString());
        ClientUI.chat.sendToServer(new Request("SET_OPEN_HOURS", hours));

        statusLabel.setText("Opening & closing hours updated");
    }
    
    private LocalTime parseTime(TextField field) {
        if (field.getText() == null || field.getText().isBlank())
            return null;
        return LocalTime.parse(field.getText());
    }
    
    
    @FXML
    private void deleteSpecialDay() {
    	LocalDate date = specialDate.getValue();
        if (date == null) {
             statusLabel.setText("Please choose a date");
             return;
          }
          ClientUI.chat.sendToServer(new Request("DELETE_SPECIAL_DAY", date));
          statusLabel.setText("Special day deleted");
    }


    private int convertDayToInt(String day) {
        return switch (day) {
            case "Sunday" -> 1;
            case "Monday" -> 2;
            case "Tuesday" -> 3;
            case "Wednesday" -> 4;
            case "Thursday" -> 5;
            case "Friday" -> 6;
            case "Saturday" -> 7;
            default -> 0; 
        };
    }
    
    @FXML
    private void exit() {
    	System.exit(0);
    }
    
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getHomeByRole();

            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("/gui/" + target));

            Scene scene = new Scene(loader.load());

            Stage stage = (Stage) ((Button) event.getSource())
                    .getScene().getWindow();

            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
    



}
