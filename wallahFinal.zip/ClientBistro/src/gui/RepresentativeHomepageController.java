package gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import navigation.Navigation;

public class RepresentativeHomepageController {

    @FXML private Button backBtn, exitBtn;

    /* ================= SIMPLE NAVIGATION ================= */
    private void switchScene(ActionEvent event, String fxml) {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + fxml)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= BUTTONS ================= */

    @FXML
    void onRegisterSubscriber(ActionEvent event) {
        switchScene(event, "RegisterSubscriber.fxml");
    }

    @FXML
    void onSubscribers(ActionEvent event) {
        switchScene(event, "SubscribersList.fxml");
    }

    @FXML
    void onActiveReservations(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/ActiveReservations.fxml")
            );

            Stage stage = new Stage();
            stage.setTitle("Active Reservations");
            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void onCurrentCustomers(ActionEvent event) {
        switchScene(event, "CurrentCustomers.fxml");
    }

    @FXML
    void onManageTables(ActionEvent event) {
        switchScene(event, "TableManagement.fxml");
    }

    @FXML
    void onViewReservations(ActionEvent event) {
        switchScene(event, "ViewReservation.fxml");
    }

    @FXML
    void onOpeningHours(ActionEvent event) {
        switchScene(event, "OpeningHours.fxml");
    }

    @FXML
    void onWaitingList(ActionEvent event) {
        switchScene(event, "ShowWaitingList.fxml");
    }

    @FXML
    private void onSubscriberDashboard(ActionEvent event) {
        switchScene(event, "SubscriberLogin.fxml");
    }

    @FXML
    private void onGuestDashboard(ActionEvent event) {
        switchScene(event, "TerminalReservation.fxml");
    }

    /* ================= BACK ================= */
    @FXML
    private void back(ActionEvent event) {
        try {
            String target = Navigation.getRoleSelectionScreen();
            System.out.println("BACK TO: " + target);

            Parent root = FXMLLoader.load(
                getClass().getResource("/gui/" + target)
            );

            Stage stage = (Stage) ((Node) event.getSource())
                    .getScene().getWindow();

            stage.setScene(new Scene(root));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* ================= EXIT ================= */
    @FXML
    private void exit() {
        System.exit(0);
    }
}
